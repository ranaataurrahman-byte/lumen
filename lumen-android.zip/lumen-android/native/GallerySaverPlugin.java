package com.lumen.camera;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Streams photos/videos from the web layer into the public gallery (DCIM/LUMEN). */
@CapacitorPlugin(
    name = "GallerySaver",
    permissions = {
        @Permission(strings = { Manifest.permission.WRITE_EXTERNAL_STORAGE }, alias = "storage")
    }
)
public class GallerySaverPlugin extends Plugin {

    private static final String FOLDER = "LUMEN";

    private static class Session {
        OutputStream out;
        Uri uri;      // API 29+
        File file;    // API < 29
        boolean video;
    }

    private final Map<String, Session> sessions = new HashMap<>();

    @PluginMethod
    public void open(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                && getPermissionState("storage") != PermissionState.GRANTED) {
            requestPermissionForAlias("storage", call, "storagePermsCallback");
            return;
        }
        doOpen(call);
    }

    @PermissionCallback
    private void storagePermsCallback(PluginCall call) {
        if (getPermissionState("storage") == PermissionState.GRANTED) {
            doOpen(call);
        } else {
            call.reject("গ্যালারি সেভের অনুমতি দেওয়া হয়নি");
        }
    }

    private void doOpen(PluginCall call) {
        String name = call.getString("name", "lumen_" + System.currentTimeMillis());
        String mime = call.getString("mime", "image/jpeg");
        String kind = call.getString("kind", "photo");
        boolean video = "video".equals(kind);
        try {
            Session s = new Session();
            s.video = video;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DCIM + "/" + FOLDER);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = video
                        ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                ContentResolver cr = getContext().getContentResolver();
                s.uri = cr.insert(collection, v);
                if (s.uri == null) {
                    call.reject("ফাইল তৈরি করা যায়নি");
                    return;
                }
                s.out = cr.openOutputStream(s.uri);
            } else {
                File dir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                        FOLDER);
                if (!dir.exists() && !dir.mkdirs()) {
                    call.reject("ফোল্ডার তৈরি করা যায়নি");
                    return;
                }
                s.file = new File(dir, name);
                s.out = new FileOutputStream(s.file);
            }
            if (s.out == null) {
                call.reject("ফাইল খোলা যায়নি");
                return;
            }
            String id = UUID.randomUUID().toString();
            synchronized (sessions) {
                sessions.put(id, s);
            }
            JSObject ret = new JSObject();
            ret.put("id", id);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("সেভ শুরু করা যায়নি: " + e.getMessage());
        }
    }

    @PluginMethod
    public void write(PluginCall call) {
        Session s = get(call.getString("id"));
        String data = call.getString("data");
        if (s == null || data == null) {
            call.reject("অবৈধ সেশন");
            return;
        }
        try {
            s.out.write(Base64.decode(data, Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("লেখা যায়নি: " + e.getMessage());
        }
    }

    @PluginMethod
    public void close(PluginCall call) {
        String id = call.getString("id");
        Session s = take(id);
        if (s == null) {
            call.reject("অবৈধ সেশন");
            return;
        }
        try {
            s.out.flush();
            s.out.close();
            JSObject ret = new JSObject();
            if (s.uri != null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContext().getContentResolver().update(s.uri, v, null, null);
                ret.put("uri", s.uri.toString());
            } else if (s.file != null) {
                MediaScannerConnection.scanFile(
                        getContext(), new String[] { s.file.getAbsolutePath() }, null, null);
                ret.put("uri", Uri.fromFile(s.file).toString());
            }
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("সেভ শেষ করা যায়নি: " + e.getMessage());
        }
    }

    @PluginMethod
    public void abort(PluginCall call) {
        Session s = take(call.getString("id"));
        if (s != null) {
            try {
                s.out.close();
            } catch (Exception ignored) {
            }
            try {
                if (s.uri != null) {
                    getContext().getContentResolver().delete(s.uri, null, null);
                } else if (s.file != null) {
                    s.file.delete();
                }
            } catch (Exception ignored) {
            }
        }
        call.resolve();
    }

    private Session get(String id) {
        if (id == null) return null;
        synchronized (sessions) {
            return sessions.get(id);
        }
    }

    private Session take(String id) {
        if (id == null) return null;
        synchronized (sessions) {
            return sessions.remove(id);
        }
    }
}
