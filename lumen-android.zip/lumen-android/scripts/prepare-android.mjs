// Run after `npx cap add android`: installs the gallery plugin + permissions.
import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const javaDir = join("android", "app", "src", "main", "java", "com", "lumen", "camera");
if (!existsSync("android")) {
  console.error("android/ ফোল্ডার নেই — আগে `npx cap add android` চালান।");
  process.exit(1);
}
mkdirSync(javaDir, { recursive: true });
copyFileSync("native/GallerySaverPlugin.java", join(javaDir, "GallerySaverPlugin.java"));
copyFileSync("native/MainActivity.java", join(javaDir, "MainActivity.java"));

const manifestPath = join("android", "app", "src", "main", "AndroidManifest.xml");
let xml = readFileSync(manifestPath, "utf8");

const perms = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
  '<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
  '<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />',
];
const missing = perms.filter((p) => !xml.includes(p.match(/android:name="([^"]+)"/)[1]));
if (missing.length) {
  xml = xml.replace("</manifest>", `    ${missing.join("\n    ")}\n</manifest>`);
  writeFileSync(manifestPath, xml);
}
console.log("Android প্রস্তুত: প্লাগিন কপি ও পারমিশন যোগ হয়েছে।");
