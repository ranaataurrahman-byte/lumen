import { useEffect, useState } from "react";
import type { GridId } from "@/lib/camera/model";
import { cn } from "@/lib/utils";

export function Guides({ grid }: { grid: GridId }) {
  if (grid === "off") return null;
  const v = grid === "golden" ? ["38.2%", "61.8%"] : grid === "cross" ? ["50%"] : ["33.333%", "66.666%"];
  const h = grid === "cross" ? ["50%"] : v;
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full text-fg/45" aria-hidden>
      {grid !== "diag" &&
        v.map((x) => <line key={`v-${x}`} x1={x} y1="0" x2={x} y2="100%" stroke="currentColor" strokeWidth="1" />)}
      {grid !== "diag" &&
        h.map((y) => <line key={`h-${y}`} x1="0" y1={y} x2="100%" y2={y} stroke="currentColor" strokeWidth="1" />)}
      {grid === "diag" && (
        <>
          <line x1="0" y1="0" x2="100%" y2="100%" stroke="currentColor" strokeWidth="1" />
          <line x1="100%" y1="0" x2="0" y2="100%" stroke="currentColor" strokeWidth="1" />
        </>
      )}
    </svg>
  );
}

export function LevelGuide({
  gamma,
  beta,
  seen,
}: {
  gamma: number;
  beta: number;
  seen: boolean;
}) {
  const [waited, setWaited] = useState(false);
  useEffect(() => {
    const id = window.setTimeout(() => setWaited(true), 900);
    return () => window.clearTimeout(id);
  }, []);
  if (!seen) {
    if (!waited) return null;
    return (
      <p className="pointer-events-none absolute inset-x-0 top-1/2 text-center text-xs text-muted">
        লেভেল সেন্সর পাওয়া যায়নি
      </p>
    );
  }
  const level = Math.abs(gamma) < 1.4;
  const pitch = Math.max(-36, Math.min(36, beta - 90));
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
      <div
        className={cn("relative h-px w-2/3", level ? "bg-primary" : "bg-fg/80")}
        style={{ transform: `rotate(${-gamma}deg) translateY(${pitch}px)` }}
      >
        <span className="absolute top-1/2 left-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-current" />
      </div>
    </div>
  );
}

export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <path
        d="M10 24V14h10M44 14h10v10M54 40v10H44M20 54H10V44"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
      />
      <circle cx="32" cy="32" r="8" fill="none" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}
