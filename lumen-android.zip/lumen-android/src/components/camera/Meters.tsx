import { useEffect, useRef, type RefObject } from "react";
import { frameCrop } from "@/lib/camera/process";

function sample(
  video: HTMLVideoElement,
  width: number,
  height: number,
  ratio: number | null,
  digital: number,
  mirror: boolean,
) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx || !video.videoWidth) return null;
  const crop = frameCrop(video.videoWidth, video.videoHeight, ratio, digital);
  ctx.filter = "none";
  if (mirror) {
    ctx.translate(width, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(video, crop.x, crop.y, crop.w, crop.h, 0, 0, width, height);
  return ctx.getImageData(0, 0, width, height);
}

export function Histogram({
  videoRef,
  active,
  ratio,
  digital,
  mirror,
}: {
  videoRef: RefObject<HTMLVideoElement | null>;
  active: boolean;
  ratio: number | null;
  digital: number;
  mirror: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!active) return;
    let stop = false;
    let last = 0;
    const tick = (now: number) => {
      if (stop) return;
      if (now - last > 180) {
        last = now;
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (video && canvas && video.videoWidth) {
          const img = sample(video, 128, 72, ratio, digital, mirror);
          const ctx = canvas.getContext("2d");
          if (img && ctx) {
            const bins = new Array<number>(32).fill(0);
            const data = img.data;
            for (let i = 0; i < data.length; i += 16) {
              const y =
                0.2126 * (data[i] ?? 0) + 0.7152 * (data[i + 1] ?? 0) + 0.0722 * (data[i + 2] ?? 0);
              const bin = Math.min(31, y >> 3);
              bins[bin] = (bins[bin] ?? 0) + 1;
            }
            const max = Math.max(1, ...bins);
            const w = (canvas.width = 128);
            const h = (canvas.height = 48);
            const color =
              getComputedStyle(canvas).getPropertyValue("--color-primary").trim() || "rgb(226,162,58)";
            ctx.clearRect(0, 0, w, h);
            ctx.fillStyle = color;
            const bw = w / bins.length;
            bins.forEach((count, i) => {
              const bh = (count / max) * (h - 2);
              ctx.globalAlpha = 0.35 + (i / bins.length) * 0.65;
              ctx.fillRect(i * bw, h - bh, Math.max(1, bw - 1), bh);
            });
            ctx.globalAlpha = 1;
          }
        }
      }
      requestAnimationFrame(tick);
    };
    const id = requestAnimationFrame(tick);
    return () => {
      stop = true;
      cancelAnimationFrame(id);
    };
  }, [active, digital, mirror, ratio, videoRef]);

  return (
    <canvas
      ref={canvasRef}
      width={128}
      height={48}
      className="h-12 w-28 rounded-sm bg-bg/55"
      aria-hidden
    />
  );
}

export function ExposureAids({
  videoRef,
  active,
  zebra,
  peaking,
  ratio,
  digital,
  mirror,
}: {
  videoRef: RefObject<HTMLVideoElement | null>;
  active: boolean;
  zebra: boolean;
  peaking: boolean;
  ratio: number | null;
  digital: number;
  mirror: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!active || (!zebra && !peaking)) return;
    let stop = false;
    let last = 0;
    const tick = (now: number) => {
      if (stop) return;
      if (now - last > 160) {
        last = now;
        const canvas = canvasRef.current;
        const video = videoRef.current;
        if (canvas && video && video.videoWidth && canvas.clientWidth > 0) {
          const w = Math.min(320, Math.max(120, Math.round(canvas.clientWidth / 2)));
          const h = Math.max(80, Math.round(w * (canvas.clientHeight / canvas.clientWidth)));
          const img = sample(video, w, h, ratio, digital, mirror);
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext("2d");
          if (img && ctx) {
            const src = img.data;
            const luma = new Float32Array(w * h);
            for (let p = 0, i = 0; p < luma.length; p += 1, i += 4) {
              luma[p] =
                0.2126 * (src[i] ?? 0) + 0.7152 * (src[i + 1] ?? 0) + 0.0722 * (src[i + 2] ?? 0);
            }
            const out = ctx.createImageData(w, h);
            const od = out.data;
            for (let y = 1; y < h - 1; y += 1) {
              for (let x = 1; x < w - 1; x += 1) {
                const i = y * w + x;
                const o = i * 4;
                const l = luma[i] ?? 0;
                let zebraOn = false;
                if (zebra && l > 235 && (x + y) % 6 < 2) zebraOn = true;
                let edge = 0;
                if (peaking) {
                  const gx =
                    -(luma[i - w - 1] ?? 0) +
                    (luma[i - w + 1] ?? 0) -
                    2 * (luma[i - 1] ?? 0) +
                    2 * (luma[i + 1] ?? 0) -
                    (luma[i + w - 1] ?? 0) +
                    (luma[i + w + 1] ?? 0);
                  const gy =
                    -(luma[i - w - 1] ?? 0) -
                    2 * (luma[i - w] ?? 0) -
                    (luma[i - w + 1] ?? 0) +
                    (luma[i + w - 1] ?? 0) +
                    2 * (luma[i + w] ?? 0) +
                    (luma[i + w + 1] ?? 0);
                  edge = Math.hypot(gx, gy);
                }
                if (zebraOn) {
                  od[o] = 243;
                  od[o + 1] = 240;
                  od[o + 2] = 232;
                  od[o + 3] = 170;
                } else if (peaking && edge > 90) {
                  od[o] = 226;
                  od[o + 1] = 70;
                  od[o + 2] = 150;
                  od[o + 3] = 200;
                }
              }
            }
            ctx.putImageData(out, 0, 0);
          }
        }
      }
      requestAnimationFrame(tick);
    };
    const id = requestAnimationFrame(tick);
    return () => {
      stop = true;
      cancelAnimationFrame(id);
    };
  }, [active, digital, mirror, peaking, ratio, videoRef, zebra]);

  if (!zebra && !peaking) return null;
  return <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden />;
}
