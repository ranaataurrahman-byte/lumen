import { useRef } from "react";
import { extFromMime, frameCrop, makeThumb, pickVideoMime } from "@/lib/camera/process";

type StartOpts = {
  video: HTMLVideoElement;
  fps: number;
  bitrate: number;
  audioStream: MediaStream | null;
  maxEdge: number;
  getRatio: () => number | null;
  getDigital: () => number;
  getFilter: () => string;
  getMirror: () => boolean;
  getVignette: () => boolean;
};

type RecResult = { blob: Blob; mime: string; thumb: Blob; width: number; height: number };

export function useRecorder() {
  const recRef = useRef<MediaRecorder | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<MediaStream | null>(null);
  const rafRef = useRef(0);
  const runningRef = useRef(false);
  const chunksRef = useRef<Blob[]>([]);
  const thumbRef = useRef<Promise<Blob> | null>(null);
  const sizeRef = useRef({ width: 0, height: 0 });
  const mimeRef = useRef("video/webm");
  const stopWait = useRef<Promise<RecResult> | null>(null);

  function isActive() {
    const state = recRef.current?.state;
    return state === "recording" || state === "paused";
  }

  async function start(opts: StartOpts) {
    await stop().catch(() => undefined);
    const video = opts.video;
    const ratio = opts.getRatio();
    const crop = frameCrop(video.videoWidth, video.videoHeight, ratio, Math.max(1, opts.getDigital()));
    const edge = Math.max(crop.w, crop.h);
    const scale = edge > opts.maxEdge ? opts.maxEdge / edge : 1;
    const width = Math.max(2, Math.round((crop.w * scale) / 2) * 2);
    const height = Math.max(2, Math.round((crop.h * scale) / 2) * 2);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    canvas.setAttribute("aria-hidden", "true");
    canvas.style.cssText =
      "position:fixed;left:-10000px;top:0;width:2px;height:2px;opacity:0;pointer-events:none";
    document.body.appendChild(canvas);
    canvasRef.current = canvas;
    sizeRef.current = { width, height };
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("রেকর্ডার তৈরি হয়নি");

    const stream = canvas.captureStream(opts.fps);
    audioRef.current = opts.audioStream;
    opts.audioStream?.getAudioTracks().forEach((t) => stream.addTrack(t));

    let mime = pickVideoMime();
    let rec: MediaRecorder;
    const recorderOpts: MediaRecorderOptions = {
      mimeType: mime,
      videoBitsPerSecond: opts.bitrate,
    };
    if (opts.audioStream) recorderOpts.audioBitsPerSecond = 128_000;
    try {
      rec = new MediaRecorder(stream, recorderOpts);
    } catch {
      rec = new MediaRecorder(stream);
      mime = rec.mimeType || "video/webm";
    }
    mimeRef.current = rec.mimeType || mime;
    chunksRef.current = [];
    thumbRef.current = null;
    rec.ondataavailable = (e) => {
      if (e.data.size) chunksRef.current.push(e.data);
    };
    recRef.current = rec;
    runningRef.current = true;

    const draw = () => {
      if (!runningRef.current) return;
      if (video.readyState >= 2 && video.videoWidth) {
        const liveCrop = frameCrop(
          video.videoWidth,
          video.videoHeight,
          opts.getRatio(),
          Math.max(1, opts.getDigital()),
        );
        const filter = opts.getFilter();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.filter = "none";
        ctx.filter = filter && filter !== "none" ? filter : "none";
        if (opts.getMirror()) {
          ctx.translate(width, 0);
          ctx.scale(-1, 1);
        }
        ctx.drawImage(video, liveCrop.x, liveCrop.y, liveCrop.w, liveCrop.h, 0, 0, width, height);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.filter = "none";
        if (opts.getVignette()) {
          const g = ctx.createRadialGradient(
            width / 2,
            height / 2,
            Math.min(width, height) * 0.38,
            width / 2,
            height / 2,
            Math.max(width, height) * 0.68,
          );
          g.addColorStop(0, "rgba(0,0,0,0)");
          g.addColorStop(1, "rgba(0,0,0,0.55)");
          ctx.fillStyle = g;
          ctx.fillRect(0, 0, width, height);
        }
        if (!thumbRef.current) {
          const snap = document.createElement("canvas");
          snap.width = width;
          snap.height = height;
          snap.getContext("2d")?.drawImage(canvas, 0, 0);
          thumbRef.current = makeThumb(snap, width, height);
        }
      }
      rafRef.current = requestAnimationFrame(draw);
    };
    draw();
    rec.start(200);
    return { width, height, mime: mimeRef.current };
  }

  function togglePause() {
    const rec = recRef.current;
    if (!rec) return "inactive" as const;
    if (rec.state === "recording") rec.pause();
    else if (rec.state === "paused") rec.resume();
    return rec.state;
  }

  function stop(): Promise<RecResult> {
    if (stopWait.current) return stopWait.current;
    const rec = recRef.current;
    const canvas = canvasRef.current;
    runningRef.current = false;
    cancelAnimationFrame(rafRef.current);
    const finish = async (): Promise<RecResult> => {
      const mime = rec && rec.mimeType ? rec.mimeType : mimeRef.current;
      const blob = new Blob(chunksRef.current, { type: mime });
      const thumb = thumbRef.current ? await thumbRef.current : new Blob();
      audioRef.current?.getTracks().forEach((t) => t.stop());
      audioRef.current = null;
      canvas?.remove();
      canvasRef.current = null;
      recRef.current = null;
      return { blob, mime, thumb, width: sizeRef.current.width, height: sizeRef.current.height };
    };
    if (!rec || rec.state === "inactive") return finish();
    const pending = new Promise<RecResult>((resolve, reject) => {
      rec.onstop = () => {
        void finish().then(resolve, reject);
      };
      rec.onerror = () => {
        void finish().then(resolve, reject);
      };
      try {
        rec.stop();
      } catch {
        void finish().then(resolve, reject);
      }
    }).finally(() => {
      stopWait.current = null;
    });
    stopWait.current = pending;
    return pending;
  }

  return { start, stop, togglePause, isActive, extFromMime };
}
