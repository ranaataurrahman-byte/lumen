import { type ReactNode } from "react";
import { toast } from "sonner";
import {
  ASPECTS,
  BURSTS,
  FILTERS,
  FPS_OPTIONS,
  GRIDS,
  ISOS,
  LAPSE_STEPS,
  QUALITIES,
  SHUTTERS,
  TIMERS,
  type CamCaps,
  type QualityId,
} from "@/lib/camera/model";
import { formatEv, lapseLabel, requestOrientation, trimZoom } from "@/lib/camera/process";
import { useSettings } from "@/lib/camera/store";
import { cn } from "@/lib/utils";
import type { LiveInfo } from "./use-camera";

function Chip({
  on,
  children,
  onClick,
  disabled,
}: {
  on?: boolean;
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "h-9 shrink-0 rounded-full border px-3 text-sm disabled:opacity-40",
        on ? "border-primary bg-primary text-bg" : "border-border bg-bg text-fg",
      )}
    >
      {children}
    </button>
  );
}

function Row({ label, value, children }: { label: string; value?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2 py-3">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-sm text-fg">{label}</p>
        {value && <p className="font-mono text-xs text-primary tabular-nums">{value}</p>}
      </div>
      {children}
    </div>
  );
}

export function ProSheet({
  open,
  onClose,
  caps,
  info,
  minZoom,
  maxZoom,
  locked,
}: {
  open: boolean;
  onClose: () => void;
  caps: CamCaps;
  info: LiveInfo;
  minZoom: number;
  maxZoom: number;
  locked: boolean;
}) {
  const s = useSettings();
  if (!open) return null;
  const guard = (fn: () => void) => {
    if (locked) {
      toast("রেকর্ড চলছে — আগে থামান");
      return;
    }
    fn();
  };

  return (
    <section
      className="sheet-panel absolute inset-x-0 bottom-0 z-20 overflow-y-auto border-t border-border bg-surface/95 px-4 pt-3 pb-4 backdrop-blur-md"
      onClick={(e) => e.stopPropagation()}
      onTouchStart={(e) => e.stopPropagation()}
    >
      <div className="mb-1 flex items-center justify-between">
        <h2 className="text-sm font-semibold tracking-wide text-fg">প্রো কন্ট্রোল</h2>
        <button type="button" onClick={onClose} className="h-9 px-2 text-sm text-muted">
          বন্ধ
        </button>
      </div>

      <Row label="এক্সপোজার EV" value={formatEv(s.ev)}>
        <input
          type="range"
          min={-3}
          max={3}
          step={0.1}
          value={s.ev}
          aria-label="এক্সপোজার"
          onChange={(e) => s.patch({ ev: Number(e.target.value) })}
        />
      </Row>

      <Row label="ISO" value={s.iso === "auto" ? "Auto" : String(s.iso)}>
        <div className="no-scrollbar flex gap-2 overflow-x-auto">
          {ISOS.map((iso) => (
            <Chip key={String(iso)} on={s.iso === iso} onClick={() => s.patch({ iso })}>
              {iso === "auto" ? "A" : iso}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="শাটার" value={SHUTTERS.find((x) => x.id === s.shutter)?.label}>
        <div className="no-scrollbar flex gap-2 overflow-x-auto">
          {SHUTTERS.map((sh) => (
            <Chip key={sh.id} on={s.shutter === sh.id} onClick={() => s.patch({ shutter: sh.id })}>
              {sh.label}
            </Chip>
          ))}
        </div>
        <p className="text-xs text-muted">১/৩০-এর চেয়ে দ্রুত শাটার এক ফ্রেম। তার চেয়ে ধীর হলে ফ্রেম জমে লং এক্সপোজার হয়।</p>
      </Row>

      <Row label="হোয়াইট ব্যালেন্স" value={s.wb === "auto" ? "Auto" : `${s.wb}K`}>
        <div className="mb-2 flex gap-2">
          <Chip on={s.wb === "auto"} onClick={() => s.patch({ wb: "auto" })}>
            Auto
          </Chip>
          <Chip on={s.wb !== "auto"} onClick={() => s.patch({ wb: typeof s.wb === "number" ? s.wb : 5600 })}>
            কেলভিন
          </Chip>
        </div>
        <input
          type="range"
          min={2500}
          max={9000}
          step={100}
          disabled={s.wb === "auto"}
          value={s.wb === "auto" ? 5600 : s.wb}
          aria-label="কেলভিন"
          onChange={(e) => s.patch({ wb: Number(e.target.value) })}
        />
      </Row>

      <Row label="জুম" value={`${trimZoom(s.zoom)}×`}>
        <input
          type="range"
          min={minZoom}
          max={maxZoom}
          step={0.1}
          value={Math.min(maxZoom, Math.max(minZoom, s.zoom))}
          aria-label="জুম"
          onChange={(e) => s.patch({ zoom: Number(e.target.value) })}
        />
      </Row>

      <Row label="অ্যাসপেক্ট">
        <div className="flex flex-wrap gap-2">
          {ASPECTS.map((a) => (
            <Chip key={a.id} on={s.aspect === a.id} onClick={() => s.patch({ aspect: a.id })}>
              {a.label}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="গ্রিড">
        <div className="flex flex-wrap gap-2">
          {GRIDS.map((g) => (
            <Chip key={g.id} on={s.grid === g.id} onClick={() => s.patch({ grid: g.id })}>
              {g.label}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="ফিল্টার">
        <div className="no-scrollbar flex gap-2 overflow-x-auto">
          {FILTERS.map((f) => (
            <Chip key={f.id} on={s.filter === f.id} onClick={() => s.patch({ filter: f.id })}>
              {f.label}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="টাইমার">
        <div className="flex gap-2">
          {TIMERS.map((t) => (
            <Chip key={t} on={s.timer === t} onClick={() => s.patch({ timer: t })}>
              {t === 0 ? "বন্ধ" : `${t}s`}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="বার্স্ট">
        <div className="flex gap-2">
          {BURSTS.map((b) => (
            <Chip key={b} on={s.burst === b} onClick={() => s.patch({ burst: b })}>
              {b === 1 ? "১" : `${b}`}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="রেজোলিউশন" value={locked ? "লক" : undefined}>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(QUALITIES) as QualityId[]).map((id) => (
            <Chip key={id} disabled={locked} on={s.quality === id} onClick={() => guard(() => s.patch({ quality: id }))}>
              {QUALITIES[id].label}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="ফ্রেমরেট">
        <div className="flex gap-2">
          {FPS_OPTIONS.map((fps) => (
            <Chip key={fps} disabled={locked} on={s.fps === fps} onClick={() => guard(() => s.patch({ fps }))}>
              {fps}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="টাইম-ল্যাপস ইন্টারভাল" value={lapseLabel(s.lapseMs)}>
        <div className="flex flex-wrap gap-2">
          {LAPSE_STEPS.map((ms) => (
            <Chip key={ms} on={s.lapseMs === ms} onClick={() => s.patch({ lapseMs: ms })}>
              {lapseLabel(ms)}
            </Chip>
          ))}
        </div>
      </Row>

      <Row label="ফরম্যাট" value={s.format === "jpeg" ? `${Math.round(s.jpeg * 100)}%` : "PNG"}>
        <div className="mb-2 flex gap-2">
          <Chip on={s.format === "jpeg"} onClick={() => s.patch({ format: "jpeg" })}>
            JPEG
          </Chip>
          <Chip on={s.format === "png"} onClick={() => s.patch({ format: "png" })}>
            PNG
          </Chip>
        </div>
        {s.format === "jpeg" && (
          <input
            type="range"
            min={0.7}
            max={1}
            step={0.01}
            value={s.jpeg}
            aria-label="JPEG কোয়ালিটি"
            onChange={(e) => s.patch({ jpeg: Number(e.target.value) })}
          />
        )}
      </Row>

      <div className="divide-y divide-border border-y border-border">
        <Toggle label="হিস্টোগ্রাম" on={s.histogram} onClick={() => s.patch({ histogram: !s.histogram })} />
        <Toggle label="জেব্রা হাইলাইট" on={s.zebra} onClick={() => s.patch({ zebra: !s.zebra })} />
        <Toggle label="ফোকাস পিকিং" on={s.peaking} onClick={() => s.patch({ peaking: !s.peaking })} />
        <Toggle
          label="হরাইজন লেভেল"
          on={s.level}
          onClick={() => {
            if (s.level) {
              s.patch({ level: false });
              return;
            }
            void requestOrientation().then((ok) => {
              if (!ok) {
                toast.error("লেভেল অনুমতি মেলেনি");
                return;
              }
              s.patch({ level: true });
            });
          }}
        />
        <Toggle label="HDR টোন" on={s.hdr} onClick={() => s.patch({ hdr: !s.hdr })} />
        <Toggle label="ভিনয়েট" on={s.vignette} onClick={() => s.patch({ vignette: !s.vignette })} />
        <Toggle label="ফ্রন্ট মিরর" on={s.mirror} onClick={() => s.patch({ mirror: !s.mirror })} />
        <Toggle label="ভিডিও মাইক" on={s.audio} onClick={() => s.patch({ audio: !s.audio })} />
        <Toggle
          label="স্ট্যাবিলাইজেশন"
          hint={caps.imageStabilization ? "ডিভাইস সাপোর্ট আছে" : "সাপোর্ট থাকলে প্রয়োগ হবে"}
          on={s.stabilization}
          onClick={() => s.patch({ stabilization: !s.stabilization })}
        />
        <Toggle label="AE/AF লক" on={s.aeLock} onClick={() => s.patch({ aeLock: !s.aeLock })} />
      </div>

      <button
        type="button"
        onClick={() => s.reset()}
        className="mt-4 h-11 w-full rounded-md border border-border text-sm text-fg"
      >
        সব রিসেট
      </button>
      <p className="mt-3 text-xs leading-relaxed text-muted">
        {info.label ? `${info.label} · ` : ""}
        {info.width ? `${info.width}×${info.height}` : "ক্যামেরা বন্ধ"}
        {caps.torch ? " · টর্চ" : ""}
        {caps.zoom ? ` · অপটিক্যাল জুম ${trimZoom(caps.zoom.min)}–${trimZoom(caps.zoom.max)}×` : " · ডিজিটাল জুম"}
        . অপটিক্যাল অ্যাপারচার ও RAW এই ওয়েব ক্যামেরায় নেই।
      </p>
    </section>
  );
}

function Toggle({
  label,
  hint,
  on,
  onClick,
}: {
  label: string;
  hint?: string;
  on: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="flex w-full items-center justify-between gap-4 py-3 text-left">
      <span>
        <span className="block text-sm text-fg">{label}</span>
        {hint && <span className="block text-xs text-muted">{hint}</span>}
      </span>
      <span className={cn("flex h-6 w-11 shrink-0 rounded-full p-0.5", on ? "bg-primary" : "bg-border")}>
        <span className={cn("block size-5 rounded-full bg-fg", on && "translate-x-5")} />
      </span>
    </button>
  );
}
