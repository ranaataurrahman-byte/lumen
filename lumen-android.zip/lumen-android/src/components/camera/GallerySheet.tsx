import { useEffect, useState } from "react";
import { format } from "date-fns";
import { bn } from "date-fns/locale";
import { ChevronLeft, ChevronRight, Download, Share2, Trash2, Video, X } from "lucide-react";
import type { Shot } from "@/lib/camera/gallery-db";
import { isNative, saveToGallery } from "@/lib/native-gallery";
import { toast } from "sonner";
import { formatBytes, formatClock } from "@/lib/camera/process";
import { cn } from "@/lib/utils";

function useObjectUrl(blob: Blob | null | undefined) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!blob || blob.size === 0 || (blob.type && !blob.type.startsWith("image") && !blob.type.startsWith("video"))) {
      setUrl(null);
      return;
    }
    const next = URL.createObjectURL(blob);
    setUrl(next);
    return () => URL.revokeObjectURL(next);
  }, [blob]);
  return url;
}

export function downloadBlob(blob: Blob, name: string) {
  if (isNative()) {
    void saveToGallery(blob, name)
      .then(() => toast.success("গ্যালারিতে সেভ হয়েছে"))
      .catch(() => toast.error("গ্যালারিতে সেভ করা যায়নি"));
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2500);
}

export async function shareOrDownload(blob: Blob, name: string) {
  if (isNative()) {
    downloadBlob(blob, name);
    return "downloaded" as const;
  }
  const file = new File([blob], name, { type: blob.type || "application/octet-stream" });
  if (navigator.canShare?.({ files: [file] })) {
    await navigator.share({ files: [file], title: "LUMEN" });
    return "shared" as const;
  }
  downloadBlob(blob, name);
  return "downloaded" as const;
}

function Thumb({ shot }: { shot: Shot }) {
  const url = useObjectUrl(shot.thumb.type.startsWith("image") ? shot.thumb : null);
  return url ? (
    <img src={url} alt="" className="h-full w-full object-cover" />
  ) : (
    <span className="flex h-full w-full items-center justify-center bg-surface text-muted">
      <Video className="size-6" />
    </span>
  );
}

export function GallerySheet({
  open,
  shots,
  onClose,
  onDelete,
}: {
  open: boolean;
  shots: Shot[];
  onClose: () => void;
  onDelete: (id: string) => Promise<void>;
}) {
  const [selected, setSelected] = useState<string | null>(null);
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!open) {
      setSelected(null);
      setArmed(false);
    }
  }, [open]);

  if (!open) return null;
  const index = shots.findIndex((s) => s.id === selected);
  const shot = index >= 0 ? shots[index] : null;

  return (
    <section className="absolute inset-0 z-40 flex flex-col bg-bg">
      <header className="safe-top flex h-14 shrink-0 items-center justify-between px-3">
        <button
          type="button"
          onClick={() => (shot ? setSelected(null) : onClose())}
          className="flex size-11 items-center justify-center rounded-full text-fg"
          aria-label={shot ? "গ্রিড" : "বন্ধ"}
        >
          {shot ? <ChevronLeft className="size-6" /> : <X className="size-6" />}
        </button>
        <h2 className="text-sm font-semibold">{shot ? shot.name : `রোল · ${shots.length}`}</h2>
        <span className="size-11" />
      </header>

      {shot ? (
        <Viewer
          shot={shot}
          armed={armed}
          onArm={() => setArmed(true)}
          onDelete={() => {
            void onDelete(shot.id).then(() => {
              setArmed(false);
              setSelected(null);
            });
          }}
          onPrev={index > 0 ? () => setSelected(shots[index - 1]!.id) : undefined}
          onNext={index < shots.length - 1 ? () => setSelected(shots[index + 1]!.id) : undefined}
        />
      ) : shots.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-2 px-8 text-center">
          <p className="text-lg text-fg">রোল খালি</p>
          <p className="text-sm text-muted">শাটার চাপলে ছবি ও ভিডিও এই ফোনেই জমা থাকবে।</p>
        </div>
      ) : (
        <div className="grid flex-1 grid-cols-3 gap-0.5 overflow-y-auto pb-8">
          {shots.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setArmed(false);
                setSelected(item.id);
              }}
              className="relative aspect-square bg-surface"
            >
              <Thumb shot={item} />
              {item.kind === "video" && (
                <span className="absolute right-1 bottom-1 rounded-sm bg-bg/75 px-1 font-mono text-xs text-fg">
                  {item.durationMs ? formatClock(item.durationMs) : "ভিডিও"}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </section>
  );
}

function Viewer({
  shot,
  armed,
  onArm,
  onDelete,
  onPrev,
  onNext,
}: {
  shot: Shot;
  armed: boolean;
  onArm: () => void;
  onDelete: () => void;
  onPrev?: () => void;
  onNext?: () => void;
}) {
  const url = useObjectUrl(shot.blob);
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="relative flex min-h-0 flex-1 items-center justify-center bg-bg">
        {shot.kind === "video" && url ? (
          <video src={url} controls playsInline className="max-h-full max-w-full" />
        ) : url ? (
          <img src={url} alt={shot.name} className="max-h-full max-w-full object-contain" />
        ) : (
          <p className="text-sm text-muted">প্রিভিউ নেই</p>
        )}
        {onPrev && (
          <button
            type="button"
            onClick={onPrev}
            className="absolute top-1/2 left-2 flex size-11 -translate-y-1/2 items-center justify-center rounded-full bg-surface/80"
            aria-label="আগেরটি"
          >
            <ChevronLeft />
          </button>
        )}
        {onNext && (
          <button
            type="button"
            onClick={onNext}
            className="absolute top-1/2 right-2 flex size-11 -translate-y-1/2 items-center justify-center rounded-full bg-surface/80"
            aria-label="পরেরটি"
          >
            <ChevronRight />
          </button>
        )}
      </div>
      <div className="safe-bottom shrink-0 border-t border-border px-4 pt-3">
        <p className="font-mono text-xs text-muted tabular-nums">
          {format(shot.created, "d MMM, HH:mm", { locale: bn })}
          {" · "}
          {shot.mode}
          {shot.width ? ` · ${shot.width}×${shot.height}` : ""}
          {" · "}
          {shot.filter}
          {" · "}
          {formatBytes(shot.blob.size)}
        </p>
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={() => downloadBlob(shot.blob, shot.name)}
            className="flex h-11 flex-1 items-center justify-center gap-2 rounded-md bg-surface text-sm"
          >
            <Download className="size-4" />
            ডাউনলোড
          </button>
          <button
            type="button"
            onClick={() => void shareOrDownload(shot.blob, shot.name)}
            className="flex h-11 flex-1 items-center justify-center gap-2 rounded-md bg-surface text-sm"
          >
            <Share2 className="size-4" />
            শেয়ার
          </button>
          <button
            type="button"
            onClick={() => (armed ? onDelete() : onArm())}
            className={cn(
              "flex h-11 flex-1 items-center justify-center gap-2 rounded-md text-sm",
              armed ? "bg-record text-fg" : "bg-surface text-fg",
            )}
          >
            <Trash2 className="size-4" />
            {armed ? "নিশ্চিত" : "মুছুন"}
          </button>
        </div>
      </div>
    </div>
  );
}
