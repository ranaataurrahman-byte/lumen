import { useEffect, useRef, useState } from "react";
import { EMPTY_CAPS, QUALITIES, type CamCaps, type Facing, type QualityId } from "@/lib/camera/model";
import { cameraErrorBn, readCaps } from "@/lib/camera/process";

export type LiveInfo = {
  width: number;
  height: number;
  fps: number;
  label: string;
};

export function useCamera(opts: {
  active: boolean;
  retry: number;
  facing: Facing;
  quality: QualityId;
  fps: number;
  onBeforeStop?: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const beforeRef = useRef(opts.onBeforeStop);
  beforeRef.current = opts.onBeforeStop;
  const [status, setStatus] = useState<"idle" | "starting" | "live" | "error">("idle");
  const [error, setError] = useState<string | null>(null);
  const [caps, setCaps] = useState<CamCaps>(EMPTY_CAPS);
  const [info, setInfo] = useState<LiveInfo>({ width: 0, height: 0, fps: 0, label: "" });

  const setVideo = (node: HTMLVideoElement | null) => {
    videoRef.current = node;
    if (node && streamRef.current && node.srcObject !== streamRef.current) {
      node.srcObject = streamRef.current;
      void node.play().catch(() => undefined);
    }
  };

  useEffect(() => {
    if (!opts.active) {
      setStatus("idle");
      return;
    }
    let cancelled = false;
    setStatus("starting");
    setError(null);
    const ac = { stream: null as MediaStream | null };

    void (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error("এই ব্রাউজারে ক্যামেরা চালানো যায় না।");
        }
        const q = QUALITIES[opts.quality];
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            facingMode: { ideal: opts.facing },
            width: { ideal: q.width },
            height: { ideal: q.height },
            frameRate: { ideal: opts.fps },
          },
        });
        ac.stream = stream;
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (video) {
          video.srcObject = stream;
          await video.play().catch(() => undefined);
        }
        const track = stream.getVideoTracks()[0];
        if (!track) throw new Error("ভিডিও ট্র্যাক নেই");
        track.onended = () => {
          if (!cancelled) {
            setStatus("error");
            setError("ক্যামেরা সংযোগ বন্ধ হয়ে গেছে।");
          }
        };
        setCaps(readCaps(track));
        const got = track.getSettings?.() ?? {};
        setInfo({
          width: got.width ?? 0,
          height: got.height ?? 0,
          fps: Math.round(got.frameRate ?? opts.fps),
          label: track.label || (opts.facing === "user" ? "ফ্রন্ট ক্যামেরা" : "ব্যাক ক্যামেরা"),
        });
        setStatus("live");
      } catch (err) {
        if (cancelled) return;
        setStatus("error");
        setError(cameraErrorBn(err));
      }
    })();

    return () => {
      cancelled = true;
      const stream = ac.stream ?? streamRef.current;
      beforeRef.current?.();
      window.setTimeout(() => {
        stream?.getTracks().forEach((t) => t.stop());
        if (streamRef.current === stream) {
          streamRef.current = null;
          if (videoRef.current?.srcObject === stream) videoRef.current.srcObject = null;
        }
      }, 180);
    };
  }, [opts.active, opts.retry, opts.facing, opts.quality, opts.fps]);

  return { setVideo, videoRef, streamRef, status, error, caps, info };
}
