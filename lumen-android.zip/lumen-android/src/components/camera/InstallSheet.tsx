import { Smartphone, X } from "lucide-react";

export function InstallSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return (
    <section className="absolute inset-0 z-40 flex items-end bg-bg/70 sm:items-center sm:justify-center">
      <div className="safe-bottom max-h-[85dvh] w-full overflow-y-auto border-t border-border bg-surface px-5 pt-5 sm:max-w-md sm:rounded-lg sm:border">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-md bg-bg text-primary">
              <Smartphone className="size-5" />
            </span>
            <div>
              <h2 className="text-base font-semibold text-fg">ফোনে LUMEN</h2>
              <p className="text-sm text-muted">ফুলস্ক্রিন ক্যামেরা, আসল লেন্স</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="flex size-11 items-center justify-center" aria-label="বন্ধ">
            <X className="size-5" />
          </button>
        </div>
        <div className="space-y-4 text-sm leading-relaxed text-fg">
          <p>
            শাটার চাপলে এই ফোনের ক্যামেরা ও মাইক ব্যবহার হবে — ছবি, ভিডিও, নাইট স্ট্যাক, টাইম-ল্যাপস ও প্যানোরামা।
          </p>
          <div>
            <p className="mb-1 font-semibold">অ্যান্ড্রয়েড</p>
            <p className="text-muted">
              Chrome-এ খুলুন, মেনু থেকে Install app বা Add to Home screen। হোম স্ক্রিনের আইকন দিয়ে ফুলস্ক্রিন ক্যামেরার
              মতো খুলবে।
            </p>
          </div>
          <div>
            <p className="mb-1 font-semibold">আইফোন</p>
            <p className="text-muted">Safari-র শেয়ার বোতাম, তারপর Add to Home Screen।</p>
          </div>
          <p className="text-muted">
            সরাসরি Play Store `.apk` ফাইল এখান থেকে বানানো যায় না — সেটার জন্য Android Studio লাগে। হোম স্ক্রিন
            ইনস্টলই ফোনে প্রো ক্যামেরা চালানোর উপায়, কোনো স্টোর ছাড়াই।
          </p>
          <div>
            <p className="mb-1 font-semibold">ডেস্কটপ শর্টকাট</p>
            <p className="text-muted">স্পেস শাটার, C ফ্লিপ, G গ্রিড, F ফ্ল্যাশ, +/− জুম। পিঞ্চ বা স্ক্রল দিয়েও জুম।</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="mt-5 mb-2 h-11 w-full rounded-md bg-primary text-sm font-semibold text-bg"
        >
          বুঝেছি
        </button>
      </div>
    </section>
  );
}
