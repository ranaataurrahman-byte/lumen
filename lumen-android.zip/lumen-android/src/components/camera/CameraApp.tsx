import { useCallback, useEffect, useRef, useState, type MouseEvent, type ReactNode, type TouchEvent } from "react";
import {
  Grid3x3,
  Images,
  Info,
  Mic,
  MicOff,
  Pause,
  Play,
  Power,
  Settings2,
  SlidersHorizontal,
  SwitchCamera,
  Timer,
  Zap,
  ZapOff,
} from "lucide-react";
import { toast, Toaster } from "sonner";
import { deleteShot, listShots, putShot, type Shot } from "@/lib/camera/gallery-db";
import {
  FILTERS,
  GRIDS,
  MODES,
  QUALITIES,
  aspectRatioOf,
  exposurePlan,
  shutterLabel,
  type FlashMode,
  type Mode,
} from "@/lib/camera/model";
import {
  applyLook,
  cameraErrorBn,
  captureStill,
  clamp,
  encodeFrames,
  extFromMime,
  fileStamp,
  focusAt,
  formatClock,
  formatEv,
  lapseLabel,
  mirroredFacing,
  PanoBuilder,
  sceneLuma,
  setTorch,
  softwareLook,
  trimZoom,
  uid,
  wait,
  type Look,
} from "@/lib/camera/process";
import { useSettings } from "@/lib/camera/store";
import { cn } from "@/lib/utils";
import { downloadBlob, GallerySheet } from "./GallerySheet";
import { isNative, saveToGallery } from "@/lib/native-gallery";
import { Guides, LevelGuide, Mark } from "./Guides";
import { InstallSheet } from "./InstallSheet";
import { ExposureAids, Histogram } from "./Meters";
import { ProSheet } from "./ProSheet";
import { useCamera } from "./use-camera";
import { useRecorder } from "./use-recorder";

const FLASHES: FlashMode[] = ["off", "on", "auto"];

function useFrameBox(ratio: number | null) {
  const outerRef = useRef<HTMLDivElement>(null);
  const [box, setBox] = useState<{ w: number; h: number } | null>(null);
  useEffect(() => {
    const el = outerRef.current;
    if (!el) return;
    const measure = () => {
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return;
      if (!ratio) {
        setBox({ w: r.width, h: r.height });
        return;
      }
      const pr = r.width / r.height;
      if (pr > ratio) setBox({ w: r.height * ratio, h: r.height });
      else setBox({ w: r.width, h: r.width / ratio });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ratio]);
  return { outerRef, box };
}

export function CameraApp() {
  const settings = useSettings();
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  const [camOn, setCamOn] = useState(false);
  const [retry, setRetry] = useState(0);
  const [shots, setShots] = useState<Shot[]>([]);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [proOpen, setProOpen] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [installOpen, setInstallOpen] = useState(false);
  const [look, setLook] = useState<Look>({ css: "none", digital: 1 });
  const [countdown, setCountdown] = useState<number | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [expose, setExpose] = useState(0);
  const [recording, setRecording] = useState(false);
  const [paused, setPaused] = useState(false);
  const [recMs, setRecMs] = useState(0);
  const [lapseOn, setLapseOn] = useState(false);
  const [lapseCount, setLapseCount] = useState(0);
  const [panoOn, setPanoOn] = useState(false);
  const [panoPx, setPanoPx] = useState(0);
  const [screenFlash, setScreenFlash] = useState(false);
  const [focus, setFocus] = useState<{ x: number; y: number; id: number } | null>(null);
  const [tilt, setTilt] = useState({ gamma: 0, beta: 90, seen: false });

  const lookRef = useRef(look);
  lookRef.current = look;
  const recordingRef = useRef(false);
  const pausedRef = useRef(false);
  const recMsRef = useRef(0);
  const busyRef = useRef(false);
  const cancelRef = useRef(false);
  const camOnRef = useRef(false);
  const statusRef = useRef<"idle" | "starting" | "live" | "error">("idle");
  const finishLock = useRef<Promise<void> | null>(null);
  const framesRef = useRef<Blob[]>([]);
  const lapseRun = useRef(false);
  const lapseTimer = useRef(0);
  const tickBusy = useRef(false);
  const panoRef = useRef<PanoBuilder | null>(null);
  const panoRun = useRef(false);
  const panoTimer = useRef(0);
  const panoUi = useRef(0);
  const panoLock = useRef(false);
  const panoViewRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const ratioRef = useRef<number | null>(null);
  const minZoomRef = useRef(1);
  const maxZoomRef = useRef(5);
  const ignoreClick = useRef(0);
  const lastTap = useRef(0);
  const pinchRef = useRef<{ dist: number; zoom: number } | null>(null);

  const recorder = useRecorder();

  const finishVideo = useCallback(async () => {
    if (finishLock.current) return finishLock.current;
    if (!recorder.isActive() && !recordingRef.current) {
      recordingRef.current = false;
      setRecording(false);
      return;
    }
    const job = (async () => {
      recordingRef.current = false;
      setRecording(false);
      setPaused(false);
      pausedRef.current = false;
      const result = await recorder.stop();
      const ms = recMsRef.current;
      recMsRef.current = 0;
      setRecMs(0);
      if (result.blob.size < 500) {
        toast.error("ক্লিপ খুব ছোট");
        return;
      }
      const s = settingsRef.current;
      await saveShot({
        kind: "video",
        blob: result.blob,
        thumb: result.thumb.size ? result.thumb : result.blob,
        width: result.width,
        height: result.height,
        mode: "ভিডিও",
        filter: FILTERS.find((f) => f.id === s.filter)?.label ?? "",
        name: fileStamp(extFromMime(result.mime)),
        mime: result.mime || "video/webm",
        durationMs: ms,
      });
    })().finally(() => {
      finishLock.current = null;
    });
    finishLock.current = job;
    return job;
  }, [recorder]);

  const cam = useCamera({
    active: camOn,
    retry,
    facing: settings.facing,
    quality: settings.quality,
    fps: settings.fps,
    onBeforeStop: () => {
      void finishVideo();
    },
  });

  const { videoRef, streamRef, status, error, caps, info } = cam;
  statusRef.current = status;
  camOnRef.current = camOn;

  const selectedRatio = aspectRatioOf(settings.aspect);
  const frame = useFrameBox(selectedRatio);
  const liveRatio =
    selectedRatio ?? (frame.box && frame.box.h > 0 ? frame.box.w / frame.box.h : null);
  ratioRef.current = liveRatio;

  const minZoom = Math.min(1, caps.zoom?.min ?? 1);
  const maxZoom = Math.max(5, caps.zoom?.max ?? 1);
  minZoomRef.current = minZoom;
  maxZoomRef.current = maxZoom;
  const locked = recording || lapseOn || panoOn;
  const mirrored = mirroredFacing(settings.mirror, settings.facing);

  useEffect(() => {
    void useSettings.persist.rehydrate();
    void listShots()
      .then(setShots)
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    if (settings.zoom > maxZoom) settings.patch({ zoom: maxZoom });
    else if (settings.zoom < minZoom) settings.patch({ zoom: minZoom });
  }, [maxZoom, minZoom, settings]);

  useEffect(() => {
    let cancel = false;
    const s = settingsRef.current;
    setLook(softwareLook(s));
    if (status !== "live") return;
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    void applyLook(
      track,
      {
        zoom: s.zoom,
        ev: s.ev,
        iso: s.iso,
        wb: s.wb,
        flash: s.flash,
        aeLock: s.aeLock,
        stabilization: s.stabilization,
        filter: s.filter,
      },
      caps,
    ).then((applied) => {
      if (!cancel) setLook(applied);
    });
    return () => {
      cancel = true;
    };
  }, [
    status,
    caps,
    settings.zoom,
    settings.ev,
    settings.iso,
    settings.wb,
    settings.flash,
    settings.filter,
    settings.aeLock,
    settings.stabilization,
    streamRef,
  ]);

  useEffect(() => {
    if (!recording) return;
    let last = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      if (!pausedRef.current) {
        recMsRef.current += now - last;
        setRecMs(recMsRef.current);
      }
      last = now;
    }, 200);
    return () => window.clearInterval(id);
  }, [recording]);

  useEffect(() => {
    if (!settings.level) return;
    let last = 0;
    const onOri = (e: DeviceOrientationEvent) => {
      const now = performance.now();
      if (now - last < 50) return;
      last = now;
      setTilt({ gamma: e.gamma ?? 0, beta: e.beta ?? 90, seen: true });
    };
    window.addEventListener("deviceorientation", onOri);
    return () => window.removeEventListener("deviceorientation", onOri);
  }, [settings.level]);

  useEffect(() => {
    const el = frameRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (statusRef.current !== "live") return;
      e.preventDefault();
      const next = clamp(
        settingsRef.current.zoom * (e.deltaY > 0 ? 0.92 : 1.08),
        minZoomRef.current,
        maxZoomRef.current,
      );
      useSettings.getState().patch({ zoom: Math.round(next * 100) / 100 });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  async function saveShot(partial: Omit<Shot, "id" | "created">) {
    const shot: Shot = { ...partial, id: uid(), created: Date.now() };
    try {
      await putShot(shot);
      setShots((prev) => [shot, ...prev]);
      if (isNative()) {
        try {
          await saveToGallery(shot.blob, shot.name, shot.mime);
          toast.success("গ্যালারিতে সেভ হয়েছে");
        } catch {
          toast.error("গ্যালারিতে সেভ হয়নি — রোল-এ আছে");
        }
      } else {
        toast.success("রোল-এ সেভ হয়েছে");
      }
    } catch {
      downloadBlob(shot.blob, shot.name);
      toast.error("স্টোরেজ ভর্তি — ফাইল ডাউনলোড হয়েছে");
    }
  }

  async function runTimer() {
    const seconds = settingsRef.current.timer;
    if (!seconds) return true;
    for (let n = seconds; n >= 1; n -= 1) {
      setCountdown(n);
      await wait(1000);
      if (cancelRef.current) {
        setCountdown(null);
        return false;
      }
    }
    setCountdown(null);
    return true;
  }

  async function withFlash(run: () => Promise<void>) {
    const s = settingsRef.current;
    const video = videoRef.current;
    const track = streamRef.current?.getVideoTracks()[0];
    const dark = s.flash === "auto" && video ? sceneLuma(video) < 72 : false;
    const need = s.flash === "on" || dark;
    if (!need || !track) {
      await run();
      return;
    }
    if (s.flash === "on" && caps.torch && s.facing === "environment") {
      await run();
      return;
    }
    let torched = false;
    if (s.facing === "environment") {
      torched = await setTorch(track, true);
      if (torched) await wait(160);
    }
    if (!torched) {
      setScreenFlash(true);
      await wait(90);
    }
    try {
      await run();
    } finally {
      setScreenFlash(false);
      if (torched && settingsRef.current.flash !== "on") await setTorch(track, false);
    }
  }

  async function shootStill() {
    const video = videoRef.current;
    if (!video?.videoWidth) {
      toast.error("ক্যামেরা প্রস্তুত নয়");
      return;
    }
    busyRef.current = true;
    cancelRef.current = false;
    try {
      if (!(await runTimer())) return;
      const s = settingsRef.current;
      const count = s.mode === "night" ? 1 : s.burst;
      for (let i = 0; i < count; i += 1) {
        if (cancelRef.current) break;
        setBusy(count > 1 ? `${i + 1} / ${count}` : s.mode === "night" ? "আলো জমছে" : null);
        await withFlash(async () => {
          const lookNow = lookRef.current;
          const still = await captureStill({
            video,
            ratio: ratioRef.current,
            digital: lookNow.digital,
            cssFilter: lookNow.css,
            mirror: mirroredFacing(s.mirror, s.facing),
            vignette: s.vignette,
            hdr: s.hdr && s.filter !== "mono" && s.filter !== "noir",
            durationMs: exposurePlan(s.mode, s.shutter),
            maxEdge: QUALITIES[s.quality].width,
            mime: s.format === "png" ? "image/png" : "image/jpeg",
            quality: s.jpeg,
            onProgress: (n) => setExpose(n),
            isCancelled: () => cancelRef.current,
          });
          await saveShot({
            kind: "photo",
            blob: still.blob,
            thumb: still.thumb,
            width: still.width,
            height: still.height,
            mode: MODES.find((m) => m.id === s.mode)?.label ?? s.mode,
            filter: FILTERS.find((f) => f.id === s.filter)?.label ?? "",
            name: fileStamp(s.format === "png" ? "png" : "jpg"),
            mime: s.format === "png" ? "image/png" : "image/jpeg",
          });
        });
        setExpose(0);
        if (i < count - 1) await wait(140);
      }
      navigator.vibrate?.(12);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") toast("এক্সপোজার বাতিল");
      else toast.error(err instanceof Error ? err.message : "ছবি হয়নি");
    } finally {
      busyRef.current = false;
      cancelRef.current = false;
      setBusy(null);
      setCountdown(null);
      setExpose(0);
    }
  }

  async function startVideo() {
    const video = videoRef.current;
    if (!video?.videoWidth) {
      toast.error("ক্যামেরা প্রস্তুত নয়");
      return;
    }
    busyRef.current = true;
    cancelRef.current = false;
    let audio: MediaStream | null = null;
    try {
      if (settingsRef.current.audio) {
        try {
          audio = await navigator.mediaDevices.getUserMedia({
            audio: { echoCancellation: true, noiseSuppression: true },
            video: false,
          });
        } catch {
          toast.error("মাইক বন্ধ — সাইলেন্ট ভিডিও হবে");
        }
      }
      if (!(await runTimer())) {
        audio?.getTracks().forEach((t) => t.stop());
        return;
      }
      const s = settingsRef.current;
      recMsRef.current = 0;
      setRecMs(0);
      pausedRef.current = false;
      setPaused(false);
      await recorder.start({
        video,
        fps: s.fps,
        bitrate: QUALITIES[s.quality].bitrate,
        audioStream: audio,
        maxEdge: QUALITIES[s.quality].width,
        getRatio: () => ratioRef.current,
        getDigital: () => lookRef.current.digital,
        getFilter: () => lookRef.current.css,
        getMirror: () => mirroredFacing(settingsRef.current.mirror, settingsRef.current.facing),
        getVignette: () => settingsRef.current.vignette,
      });
      recordingRef.current = true;
      setRecording(true);
      navigator.vibrate?.(15);
    } catch (err) {
      audio?.getTracks().forEach((t) => t.stop());
      toast.error(cameraErrorBn(err));
    } finally {
      busyRef.current = false;
      setCountdown(null);
    }
  }

  function beginLapse() {
    const video = videoRef.current;
    if (!video?.videoWidth) {
      toast.error("ক্যামেরা প্রস্তুত নয়");
      return;
    }
    framesRef.current = [];
    setLapseCount(0);
    lapseRun.current = true;
    setLapseOn(true);
    const tick = async () => {
      if (!lapseRun.current || !videoRef.current) return;
      tickBusy.current = true;
      try {
        const s = settingsRef.current;
        const frameStill = await captureStill({
          video: videoRef.current,
          ratio: ratioRef.current,
          digital: lookRef.current.digital,
          cssFilter: lookRef.current.css,
          mirror: mirroredFacing(s.mirror, s.facing),
          vignette: s.vignette,
          hdr: false,
          durationMs: 0,
          maxEdge: 1280,
          mime: "image/jpeg",
          quality: 0.84,
        });
        if (lapseRun.current) {
          framesRef.current.push(frameStill.blob);
          setLapseCount(framesRef.current.length);
        }
      } catch {
        /* skip a missed frame */
      } finally {
        tickBusy.current = false;
      }
      if (lapseRun.current) {
        lapseTimer.current = window.setTimeout(() => void tick(), settingsRef.current.lapseMs);
      }
    };
    void tick();
  }

  async function finishLapse() {
    lapseRun.current = false;
    setLapseOn(false);
    window.clearTimeout(lapseTimer.current);
    while (tickBusy.current) await wait(30);
    const frames = framesRef.current.splice(0);
    setLapseCount(0);
    if (frames.length < 2) {
      toast.error("আরও কিছুক্ষণ রেখে তারপর থামান");
      return;
    }
    busyRef.current = true;
    setBusy("ভিডিও তৈরি হচ্ছে");
    try {
      const blob = await encodeFrames(frames, 30);
      const s = settingsRef.current;
      await saveShot({
        kind: "video",
        blob,
        thumb: frames[0]!,
        width: 0,
        height: 0,
        mode: "ল্যাপস",
        filter: FILTERS.find((f) => f.id === s.filter)?.label ?? "",
        name: fileStamp(extFromMime(blob.type || "video/webm")),
        mime: blob.type || "video/webm",
        durationMs: Math.round((frames.length / 30) * 1000),
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "ল্যাপস হয়নি");
    } finally {
      busyRef.current = false;
      setBusy(null);
    }
  }

  function beginPano() {
    const video = videoRef.current;
    if (!video?.videoWidth) {
      toast.error("ক্যামেরা প্রস্তুত নয়");
      return;
    }
    panoRef.current = new PanoBuilder(Math.min(1080, video.videoHeight || 720));
    panoRun.current = true;
    setPanoOn(true);
    setPanoPx(0);
    const loop = () => {
      if (!panoRun.current) return;
      const builder = panoRef.current;
      const v = videoRef.current;
      if (builder && v) {
        const s = settingsRef.current;
        const pushed = builder.push(v, mirroredFacing(s.mirror, s.facing), lookRef.current.css);
        if (pushed === "full") {
          void finishPano();
          return;
        }
        const now = performance.now();
        if (now - panoUi.current > 180) {
          panoUi.current = now;
          setPanoPx(builder.used);
          const view = panoViewRef.current;
          if (view && builder.used > 2) {
            const ph = 72;
            const pw = Math.max(2, Math.min(1200, Math.round((builder.used / builder.height) * ph)));
            view.width = pw;
            view.height = ph;
            view.getContext("2d")?.drawImage(builder.canvas, 0, 0, builder.used, builder.height, 0, 0, pw, ph);
          }
        }
      }
      panoTimer.current = window.setTimeout(loop, 80);
    };
    loop();
  }

  async function finishPano() {
    if (panoLock.current) return;
    panoLock.current = true;
    panoRun.current = false;
    setPanoOn(false);
    window.clearTimeout(panoTimer.current);
    const builder = panoRef.current;
    panoRef.current = null;
    if (!builder) {
      panoLock.current = false;
      return;
    }
    busyRef.current = true;
    setBusy("প্যানো সেভ হচ্ছে");
    try {
      const out = await builder.exportJpeg(settingsRef.current.jpeg);
      const s = settingsRef.current;
      await saveShot({
        kind: "photo",
        blob: out.blob,
        thumb: out.thumb,
        width: out.width,
        height: out.height,
        mode: "প্যানো",
        filter: FILTERS.find((f) => f.id === s.filter)?.label ?? "",
        name: fileStamp("jpg"),
        mime: "image/jpeg",
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "প্যানো হয়নি");
    } finally {
      busyRef.current = false;
      setBusy(null);
      setPanoPx(0);
      panoLock.current = false;
    }
  }

  async function pressShutter() {
    if (statusRef.current === "starting") return;
    if (recordingRef.current) {
      await finishVideo();
      return;
    }
    if (lapseRun.current) {
      await finishLapse();
      return;
    }
    if (panoRun.current) {
      await finishPano();
      return;
    }
    if (!camOnRef.current || statusRef.current === "error" || statusRef.current === "idle") {
      if (statusRef.current === "error") setRetry((n) => n + 1);
      setCamOn(true);
      return;
    }
    if (busyRef.current) {
      cancelRef.current = true;
      return;
    }
    const mode = settingsRef.current.mode;
    if (mode === "video") return startVideo();
    if (mode === "lapse") return beginLapse();
    if (mode === "pano") return beginPano();
    return shootStill();
  }

  const pressRef = useRef(pressShutter);
  pressRef.current = pressShutter;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === "Escape") {
        setGalleryOpen(false);
        setInstallOpen(false);
        setProOpen(false);
        setFiltersOpen(false);
        return;
      }
      if (e.target instanceof HTMLButtonElement) return;
      if (e.code === "Space") {
        e.preventDefault();
        void pressRef.current();
      } else if (e.key === "c" || e.key === "C") {
        flip();
      } else if (e.key === "g" || e.key === "G") {
        cycleGrid();
      } else if (e.key === "f" || e.key === "F") {
        cycleFlash();
      } else if (e.key === "+" || e.key === "=") {
        nudgeZoom(1.15);
      } else if (e.key === "-" || e.key === "_") {
        nudgeZoom(0.87);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function nudgeZoom(factor: number) {
    const next = clamp(settingsRef.current.zoom * factor, minZoomRef.current, maxZoomRef.current);
    settings.patch({ zoom: Math.round(next * 100) / 100 });
  }

  function cycleGrid() {
    const order = GRIDS.map((g) => g.id);
    const i = order.indexOf(settingsRef.current.grid);
    settings.patch({ grid: order[(i + 1) % order.length] ?? "thirds" });
  }

  function cycleFlash() {
    const i = FLASHES.indexOf(settingsRef.current.flash);
    settings.patch({ flash: FLASHES[(i + 1) % FLASHES.length] ?? "off" });
  }

  function flip() {
    if (recordingRef.current || lapseRun.current || panoRun.current) {
      toast("আগে থামান");
      return;
    }
    settings.patch({ facing: settingsRef.current.facing === "user" ? "environment" : "user" });
  }

  function selectMode(mode: Mode) {
    if (locked) {
      toast("আগে শাটার দিয়ে থামান");
      return;
    }
    settings.patch({ mode });
  }

  async function powerOff() {
    if (recordingRef.current) await finishVideo();
    if (lapseRun.current) await finishLapse();
    if (panoRun.current) await finishPano();
    setCamOn(false);
  }

  function onFrameClick(e: MouseEvent<HTMLDivElement>) {
    if (performance.now() < ignoreClick.current) return;
    if (status !== "live") {
      void pressShutter();
      return;
    }
    const el = frameRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = (e.clientY - r.top) / r.height;
    if (x < 0 || y < 0 || x > 1 || y > 1) return;
    const now = performance.now();
    if (now - lastTap.current < 280) {
      const z = settings.zoom > 1.15 ? 1 : Math.min(2, maxZoom);
      settings.patch({ zoom: z });
      lastTap.current = 0;
      return;
    }
    lastTap.current = now;
    setFocus({ x, y, id: now });
    const track = streamRef.current?.getVideoTracks()[0];
    if (track) void focusAt(track, x, y, caps, mirrored);
  }

  function onTouchStart(e: TouchEvent) {
    if (e.touches.length === 2) {
      const a = e.touches[0]!;
      const b = e.touches[1]!;
      pinchRef.current = {
        dist: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY),
        zoom: settingsRef.current.zoom,
      };
    }
  }

  function onTouchMove(e: TouchEvent) {
    if (e.touches.length === 2 && pinchRef.current) {
      const a = e.touches[0]!;
      const b = e.touches[1]!;
      const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      const next = clamp(
        pinchRef.current.zoom * (dist / Math.max(1, pinchRef.current.dist)),
        minZoom,
        maxZoom,
      );
      settings.patch({ zoom: Math.round(next * 100) / 100 });
    }
  }

  function onTouchEnd() {
    if (pinchRef.current) {
      pinchRef.current = null;
      ignoreClick.current = performance.now() + 400;
    }
  }

  const zoomMarks = [0.5, 1, 2, 3, 5].filter((z) => z >= minZoom - 0.05 && z <= maxZoom + 0.05);
  const hot = settings.mode === "video" || recording || lapseOn;
  const stopping = recording || lapseOn || panoOn;
  const hint =
    status === "idle"
      ? "শাটার চাপুন — ক্যামেরা চালু হবে"
      : status === "starting"
        ? "ক্যামেরা সংযোগ হচ্ছে…"
        : status === "error"
          ? error
          : panoOn
            ? "ধীরে ডানে ঘুরান। থামলে স্ট্রিপ যোগ হয় না।"
            : lapseOn
              ? `${lapseCount} ফ্রেম জমা`
              : settings.mode === "night"
                ? "স্থির থাকুন — একাধিক ফ্রেম মিশে নয়েজ কমবে"
                : settings.mode === "pro"
                  ? `ম্যানুয়াল · ${shutterLabel(settings.shutter)} · ISO ${settings.iso === "auto" ? "A" : settings.iso}`
                  : settings.mode === "lapse"
                    ? `ইন্টারভাল ${lapseLabel(settings.lapseMs)}`
                    : null;

  const tele =
    settings.mode === "video"
      ? `${QUALITIES[settings.quality].label} · ${settings.fps} · ${settings.audio ? "MIC" : "MUTE"}`
      : `EV ${formatEv(settings.ev)} · ${shutterLabel(settings.shutter)} · ISO ${settings.iso === "auto" ? "A" : settings.iso}${settings.wb === "auto" ? "" : ` · ${settings.wb}K`}`;

  const latest = shots[0];

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <Toaster theme="dark" position="top-center" offset={64} />
      <header className="safe-top z-10 flex h-14 shrink-0 items-center justify-between gap-2 px-3">
        <div className="flex items-center gap-2">
          <Mark className="size-6 text-primary" />
          <span className="text-sm font-semibold tracking-[0.18em]">LUMEN</span>
        </div>
        <div className="flex items-center">
          <IconButton label="ফিল্টার" onClick={() => setFiltersOpen((v) => !v)} active={settings.filter !== "standard" || filtersOpen}>
            <SlidersHorizontal className="size-5" />
          </IconButton>
          <IconButton label="গ্রিড" onClick={cycleGrid} active={settings.grid !== "off"}>
            <Grid3x3 className="size-5" />
          </IconButton>
          <IconButton label="প্রো" onClick={() => setProOpen((v) => !v)} active={proOpen}>
            <Settings2 className="size-5" />
          </IconButton>
          {!isNative() && (
            <IconButton label="ফোনে ইনস্টল" onClick={() => setInstallOpen(true)}>
              <Info className="size-5" />
            </IconButton>
          )}
          {camOn && (
            <IconButton label="ক্যামেরা বন্ধ" onClick={() => void powerOff()}>
              <Power className="size-5" />
            </IconButton>
          )}
        </div>
      </header>

      <div ref={frame.outerRef} className="relative min-h-0 flex-1">
        <div
          ref={frameRef}
          className="viewfinder absolute overflow-hidden bg-bg"
          style={
            settings.aspect === "full" || !frame.box
              ? { inset: 0 }
              : {
                  width: frame.box.w,
                  height: frame.box.h,
                  left: "50%",
                  top: "50%",
                  transform: "translate(-50%, -50%)",
                }
          }
          onClick={onFrameClick}
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
          onContextMenu={(e) => e.preventDefault()}
        >
          <video
            ref={cam.setVideo}
            playsInline
            muted
            autoPlay
            className={cn("h-full w-full object-cover", status === "live" ? "opacity-100" : "opacity-0")}
            style={{
              transform: `scale(${look.digital}) scaleX(${mirrored ? -1 : 1})`,
              filter: look.css,
            }}
          />
          {status !== "live" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-8 text-center">
              <Mark className="size-16 text-primary" />
              <p className="text-lg font-semibold">LUMEN</p>
              <p className="max-w-xs text-sm text-muted">
                {status === "error"
                  ? error
                  : status === "starting"
                    ? "ক্যামেরা সংযোগ হচ্ছে…"
                    : "লেন্স বন্ধ। শাটার চাপলে ফোনের আসল ক্যামেরা চালু হবে।"}
              </p>
            </div>
          )}
          <Guides grid={settings.grid} />
          {settings.level && <LevelGuide gamma={tilt.gamma} beta={tilt.beta} seen={tilt.seen} />}
          {settings.vignette && (
            <div
              className="pointer-events-none absolute inset-0"
              style={{
                background:
                  "radial-gradient(ellipse at center, transparent 52%, color-mix(in srgb, var(--color-bg) 72%, transparent) 100%)",
              }}
            />
          )}
          <ExposureAids
            videoRef={videoRef}
            active={status === "live"}
            zebra={settings.zebra}
            peaking={settings.peaking}
            ratio={liveRatio}
            digital={look.digital}
            mirror={mirrored}
          />
          {focus && (
            <span
              key={focus.id}
              className="focus-box pointer-events-none absolute"
              style={{ left: `${focus.x * 100}%`, top: `${focus.y * 100}%` }}
            />
          )}
          <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3">
            <div className="min-w-0">
              {recording && (
                <p className="flex items-center gap-2 font-mono text-sm text-record tabular-nums">
                  <span className="rec-dot size-2 rounded-full bg-record" />
                  {paused ? "PAUSE" : "REC"} {formatClock(recMs)}
                </p>
              )}
              <p className="mt-1 font-mono text-xs text-fg/90 tabular-nums">{tele}</p>
              {info.width > 0 && status === "live" && (
                <p className="font-mono text-xs text-muted tabular-nums">
                  {info.width}×{info.height}
                  {info.fps ? ` · ${info.fps}fps` : ""}
                </p>
              )}
            </div>
            {settings.histogram && status === "live" && (
              <Histogram
                videoRef={videoRef}
                active
                ratio={liveRatio}
                digital={look.digital}
                mirror={mirrored}
              />
            )}
          </div>
          {countdown !== null && (
            <div className="absolute inset-0 flex items-center justify-center bg-bg/35">
              <span className="font-mono text-7xl text-fg tabular-nums">{countdown}</span>
            </div>
          )}
          {busy && (
            <p className="absolute bottom-16 left-1/2 -translate-x-1/2 rounded-full bg-bg/70 px-3 py-1 text-xs text-fg">
              {busy}
            </p>
          )}
          {panoOn && (
            <div className="pointer-events-none absolute inset-x-3 bottom-3">
              <canvas ref={panoViewRef} className="h-16 max-w-full rounded-sm bg-bg/40" />
              <p className="mt-1 font-mono text-xs text-primary">{panoPx}px</p>
            </div>
          )}
        </div>
        {filtersOpen && (
          <div className="absolute inset-x-0 bottom-0 z-20 flex gap-2 overflow-x-auto bg-bg/80 p-3 no-scrollbar">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => settings.patch({ filter: f.id })}
                className={cn(
                  "h-10 shrink-0 rounded-full px-3 text-sm",
                  settings.filter === f.id ? "bg-primary text-bg" : "bg-surface text-fg",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        )}
        <ProSheet
          open={proOpen}
          onClose={() => setProOpen(false)}
          caps={caps}
          info={info}
          minZoom={minZoom}
          maxZoom={maxZoom}
          locked={locked}
        />
      </div>

      <footer className="safe-bottom z-10 shrink-0 px-3 pt-2">
        {hint && <p className="mb-2 truncate text-center text-xs text-muted">{hint}</p>}
        <div className="mb-2 flex items-center justify-center gap-2">
          {zoomMarks.map((z) => (
            <button
              key={z}
              type="button"
              onClick={() => settings.patch({ zoom: z })}
              className={cn(
                "h-8 min-w-11 rounded-full px-2 font-mono text-xs tabular-nums",
                Math.abs(settings.zoom - z) < 0.15 ? "bg-primary text-bg" : "text-muted",
              )}
            >
              {trimZoom(z)}×
            </button>
          ))}
          {zoomMarks.length === 0 && (
            <span className="font-mono text-xs text-primary">{trimZoom(settings.zoom)}×</span>
          )}
        </div>
        <div className="no-scrollbar mb-3 flex items-center justify-center gap-4 overflow-x-auto px-2">
          {MODES.map((mode) => (
            <button
              key={mode.id}
              type="button"
              onClick={() => selectMode(mode.id)}
              className={cn(
                "h-11 shrink-0 text-sm font-semibold tracking-wide",
                settings.mode === mode.id ? "text-primary" : "text-muted",
              )}
            >
              {mode.label}
            </button>
          ))}
        </div>
        <div className="mx-auto flex max-w-lg items-center justify-between px-2 pb-2">
          <button
            type="button"
            onClick={() => setGalleryOpen(true)}
            className="relative size-12 overflow-hidden rounded-md border border-border bg-surface"
            aria-label="গ্যালারি"
          >
            {latest && latest.thumb.type.startsWith("image") ? (
              <RollThumb blob={latest.thumb} />
            ) : (
              <span className="flex h-full items-center justify-center text-muted">
                <Images className="size-5" />
              </span>
            )}
            {shots.length > 0 && (
              <span className="absolute right-0 bottom-0 bg-bg/80 px-1 font-mono text-xs text-fg">{shots.length}</span>
            )}
          </button>
          <IconButton
            label={settings.timer ? `টাইমার ${settings.timer} সেকেন্ড` : "টাইমার"}
            onClick={() => {
              const order = [0, 3, 5, 10] as const;
              const i = order.indexOf(settings.timer);
              settings.patch({ timer: order[(i + 1) % order.length] ?? 0 });
            }}
            active={settings.timer > 0}
          >
            <span className="flex flex-col items-center">
              <Timer className="size-5" />
              {settings.timer > 0 && <span className="font-mono text-xs">{settings.timer}</span>}
            </span>
          </IconButton>
          <button
            type="button"
            onClick={() => void pressShutter()}
            aria-label={stopping ? "থামান" : "শাটার"}
            className={cn(
              "relative flex size-20 items-center justify-center rounded-full",
              hot || panoOn ? "shutter-ring-hot" : "shutter-ring",
            )}
          >
            <span
              className={cn(
                "block",
                stopping ? "size-7 rounded-sm bg-record" : hot ? "size-14 rounded-full bg-record" : "size-14 rounded-full bg-fg",
              )}
            />
            {expose > 0 && (
              <svg className="pointer-events-none absolute -inset-2 -rotate-90 text-primary" viewBox="0 0 88 88" aria-hidden>
                <circle
                  cx="44"
                  cy="44"
                  r="40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeDasharray={`${Math.max(0.04, expose) * 251} 251`}
                />
              </svg>
            )}
          </button>
          <IconButton label="ফ্ল্যাশ" onClick={cycleFlash} active={settings.flash !== "off"}>
            <span className="relative">
              {settings.flash === "off" ? <ZapOff className="size-5" /> : <Zap className="size-5" />}
              {settings.flash === "auto" && (
                <span className="absolute -top-2 -right-2 font-mono text-xs text-primary">A</span>
              )}
            </span>
          </IconButton>
          {recording ? (
            <IconButton label={paused ? "চালিয়ে যান" : "বিরতি"} onClick={() => {
              const state = recorder.togglePause();
              const next = state === "paused";
              pausedRef.current = next;
              setPaused(next);
            }}>
              {paused ? <Play className="size-5" /> : <Pause className="size-5" />}
            </IconButton>
          ) : (
            <IconButton label="ক্যামেরা উল্টান" onClick={flip}>
              <SwitchCamera className="size-5" />
            </IconButton>
          )}
        </div>
        <p className="pb-1 text-center text-xs text-muted">
          {settings.audio ? <Mic className="mr-1 inline size-3" /> : <MicOff className="mr-1 inline size-3" />}
          {settings.mode === "video" ? "ভিডিওতে মাইক" : "ডাবল-ট্যাপ ১×/২× · পিঞ্চ জুম"}
        </p>
      </footer>

      {screenFlash && <div className="absolute inset-0 z-50 bg-fg" />}
      <GallerySheet
        open={galleryOpen}
        shots={shots}
        onClose={() => setGalleryOpen(false)}
        onDelete={async (id) => {
          await deleteShot(id);
          setShots((prev) => prev.filter((s) => s.id !== id));
        }}
      />
      <InstallSheet open={installOpen} onClose={() => setInstallOpen(false)} />
    </div>
  );
}

function IconButton({
  children,
  label,
  onClick,
  active,
}: {
  children: ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={cn(
        "flex size-11 items-center justify-center rounded-full",
        active ? "text-primary" : "text-fg",
      )}
    >
      {children}
    </button>
  );
}

function RollThumb({ blob }: { blob: Blob }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    const next = URL.createObjectURL(blob);
    setUrl(next);
    return () => URL.revokeObjectURL(next);
  }, [blob]);
  if (!url) return null;
  return <img src={url} alt="" className="h-full w-full object-cover" />;
}
