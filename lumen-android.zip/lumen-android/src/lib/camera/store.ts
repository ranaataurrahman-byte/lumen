import { create } from "zustand";
import { persist } from "zustand/middleware";
import { defaultSettings, type Settings } from "./model";

type State = Settings & {
  patch: (partial: Partial<Settings>) => void;
  reset: () => void;
};

export const useSettings = create<State>()(
  persist(
    (set) => ({
      ...defaultSettings,
      patch: (partial) => set(partial),
      reset: () => set({ ...defaultSettings }),
    }),
    {
      name: "lumen-settings-v1",
      skipHydration: true,
      partialize: (state) => {
        const { patch: _patch, reset: _reset, ...data } = state;
        return data;
      },
    },
  ),
);
