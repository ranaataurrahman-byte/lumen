export const MODES = [
  { id: "photo", label: "ছবি" },
  { id: "video", label: "ভিডিও" },
  { id: "night", label: "নাইট" },
  { id: "pro", label: "প্রো" },
  { id: "lapse", label: "ল্যাপস" },
  { id: "pano", label: "প্যানো" },
] as const;

export type Mode = (typeof MODES)[number]["id"];

export const FILTERS = [
  { id: "standard", label: "স্ট্যান্ডার্ড", css: "" },
  { id: "vivid", label: "ভিভিড", css: "contrast(1.12) saturate(1.35)" },
  { id: "neutral", label: "নিউট্রাল", css: "contrast(0.96) saturate(0.88)" },
  { id: "mono", label: "মনো", css: "grayscale(1) contrast(1.08)" },
  { id: "noir", label: "নয়ার", css: "grayscale(1) contrast(1.32) brightness(0.92)" },
  { id: "chrome", label: "ক্রোম", css: "contrast(1.16) saturate(1.12)" },
  { id: "warm", label: "ওয়ার্ম", css: "sepia(0.2) saturate(1.16) contrast(1.04)" },
  { id: "cool", label: "কুল", css: "saturate(0.9) hue-rotate(12deg) brightness(1.03)" },
  { id: "fade", label: "ফেড", css: "contrast(0.88) brightness(1.08) saturate(0.8)" },
  {
    id: "cinema",
    label: "সিনেমা",
    css: "contrast(1.08) saturate(0.8) sepia(0.16) hue-rotate(-8deg)",
  },
] as const;

export type FilterId = (typeof FILTERS)[number]["id"];

export const GRIDS = [
  { id: "off", label: "বন্ধ" },
  { id: "thirds", label: "থার্ডস" },
  { id: "golden", label: "গোল্ডেন" },
  { id: "cross", label: "ক্রস" },
  { id: "diag", label: "ডায়াগ" },
] as const;

export type GridId = (typeof GRIDS)[number]["id"];

export const ASPECTS = [
  { id: "full", label: "ফুল", ratio: null },
  { id: "16:9", label: "16:9", ratio: 16 / 9 },
  { id: "4:3", label: "4:3", ratio: 4 / 3 },
  { id: "3:2", label: "3:2", ratio: 3 / 2 },
  { id: "1:1", label: "1:1", ratio: 1 },
] as const;

export type AspectId = (typeof ASPECTS)[number]["id"];

export const QUALITIES = {
  "720": { width: 1280, height: 720, bitrate: 4_000_000, label: "720p" },
  "1080": { width: 1920, height: 1080, bitrate: 10_000_000, label: "1080p" },
  "1440": { width: 2560, height: 1440, bitrate: 16_000_000, label: "1440p" },
  "2160": { width: 3840, height: 2160, bitrate: 28_000_000, label: "4K" },
} as const;

export type QualityId = keyof typeof QUALITIES;

export const FPS_OPTIONS = [24, 30, 60] as const;
export type Fps = (typeof FPS_OPTIONS)[number];

export const SHUTTERS = [
  { id: "auto", label: "Auto", ms: 0 },
  { id: "1/500", label: "1/500", ms: 2 },
  { id: "1/250", label: "1/250", ms: 4 },
  { id: "1/125", label: "1/125", ms: 8 },
  { id: "1/60", label: "1/60", ms: 17 },
  { id: "1/30", label: "1/30", ms: 33 },
  { id: "1/15", label: "1/15", ms: 66 },
  { id: "1/8", label: "1/8", ms: 125 },
  { id: "1/4", label: "1/4", ms: 250 },
  { id: "1/2", label: "1/2", ms: 500 },
  { id: "1s", label: "1″", ms: 1000 },
  { id: "2s", label: "2″", ms: 2000 },
  { id: "4s", label: "4″", ms: 4000 },
] as const;

export type ShutterId = (typeof SHUTTERS)[number]["id"];

export const ISOS = ["auto", 100, 200, 400, 800, 1600, 3200, 6400] as const;
export type Iso = (typeof ISOS)[number];

export const TIMERS = [0, 3, 5, 10] as const;
export const BURSTS = [1, 3, 5, 10] as const;
export const LAPSE_STEPS = [500, 1000, 2000, 5000, 10000] as const;

export type Facing = "user" | "environment";
export type FlashMode = "off" | "on" | "auto";
export type StillFormat = "jpeg" | "png";

export type RangeCap = { min: number; max: number; step?: number };

export type CamCaps = {
  zoom?: RangeCap;
  torch: boolean;
  exposureCompensation?: RangeCap;
  colorTemperature?: RangeCap;
  focusModes: string[];
  exposureModes: string[];
  whiteBalanceModes: string[];
  pointsOfInterest: boolean;
  imageStabilization: boolean;
};

export const EMPTY_CAPS: CamCaps = {
  torch: false,
  focusModes: [],
  exposureModes: [],
  whiteBalanceModes: [],
  pointsOfInterest: false,
  imageStabilization: false,
};

export type Settings = {
  mode: Mode;
  facing: Facing;
  zoom: number;
  ev: number;
  iso: Iso;
  shutter: ShutterId;
  wb: number | "auto";
  filter: FilterId;
  grid: GridId;
  aspect: AspectId;
  timer: (typeof TIMERS)[number];
  burst: (typeof BURSTS)[number];
  flash: FlashMode;
  mirror: boolean;
  histogram: boolean;
  zebra: boolean;
  peaking: boolean;
  level: boolean;
  audio: boolean;
  fps: Fps;
  quality: QualityId;
  jpeg: number;
  format: StillFormat;
  stabilization: boolean;
  hdr: boolean;
  vignette: boolean;
  aeLock: boolean;
  lapseMs: (typeof LAPSE_STEPS)[number];
};

export const defaultSettings: Settings = {
  mode: "photo",
  facing: "environment",
  zoom: 1,
  ev: 0,
  iso: "auto",
  shutter: "auto",
  wb: "auto",
  filter: "standard",
  grid: "thirds",
  aspect: "4:3",
  timer: 0,
  burst: 1,
  flash: "off",
  mirror: true,
  histogram: true,
  zebra: false,
  peaking: false,
  level: false,
  audio: true,
  fps: 30,
  quality: "1080",
  jpeg: 0.92,
  format: "jpeg",
  stabilization: true,
  hdr: true,
  vignette: false,
  aeLock: false,
  lapseMs: 1000,
};

export function aspectRatioOf(id: AspectId): number | null {
  return ASPECTS.find((a) => a.id === id)?.ratio ?? null;
}

export function shutterMs(id: ShutterId): number {
  return SHUTTERS.find((s) => s.id === id)?.ms ?? 0;
}

export function shutterLabel(id: ShutterId): string {
  return SHUTTERS.find((s) => s.id === id)?.label ?? "Auto";
}

export function filterCss(id: FilterId): string {
  return FILTERS.find((f) => f.id === id)?.css ?? "";
}

export function exposurePlan(mode: Mode, shutter: ShutterId): number {
  const base = shutterMs(shutter);
  if (mode === "night") return Math.max(base, 1200);
  return base;
}
