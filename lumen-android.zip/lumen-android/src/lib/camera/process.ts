import {
  type CamCaps,
  type Facing,
  type FilterId,
  type FlashMode,
  type Iso,
  filterCss,
} from "./model";

export function clamp(n: number, a: number, b: number) {
  return Math.min(b, Math.max(a, n));
}

export function clamp8(n: number) {
  if (n <= 0) return 0;
  if (n >= 255) return 255;
  return n | 0;
}

export const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export function uid() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `lumen-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function isoStops(iso: Iso) {
  if (iso === "auto") return 0;
  return Math.log2(iso / 100) * 0.45;
}

export function kelvinCss(k: number) {
  if (Math.abs(k - 5600) < 80) return "";
  if (k < 5600) {
    const amt = clamp((5600 - k) / 3200, 0, 1);
    return `sepia(${(amt * 0.48).toFixed(3)}) saturate(${(1 + amt * 0.28).toFixed(3)}) hue-rotate(${(-10 * amt).toFixed(2)}deg)`;
  }
  const amt = clamp((k - 5600) / 3400, 0, 1);
  return `hue-rotate(${(16 * amt).toFixed(2)}deg) saturate(${(1 - amt * 0.12).toFixed(3)}) brightness(${(1 + amt * 0.05).toFixed(3)})`;
}

export function exposureCss(ev: number) {
  if (Math.abs(ev) < 0.04) return "";
  return `brightness(${Math.pow(2, ev).toFixed(3)})`;
}

export function composeCss(filter: FilterId, evLeft: number, wb: number | "auto", wbSoftware: boolean) {
  const parts = [
    filterCss(filter),
    wbSoftware && wb !== "auto" ? kelvinCss(wb) : "",
    exposureCss(evLeft),
  ].filter(Boolean);
  return parts.join(" ") || "none";
}

export type Crop = { x: number; y: number; w: number; h: number };

export function frameCrop(srcW: number, srcH: number, ratio: number | null, digitalZoom: number): Crop {
  const z = Math.max(1, digitalZoom);
  if (srcW < 2 || srcH < 2) return { x: 0, y: 0, w: Math.max(2, srcW), h: Math.max(2, srcH) };
  let x = 0;
  let y = 0;
  let w = srcW;
  let h = srcH;
  if (ratio && ratio > 0) {
    const srcR = srcW / srcH;
    if (srcR > ratio) {
      w = srcH * ratio;
      x = (srcW - w) / 2;
    } else {
      h = srcW / ratio;
      y = (srcH - h) / 2;
    }
  }
  const zw = w / z;
  const zh = h / z;
  return { x: x + (w - zw) / 2, y: y + (h - zh) / 2, w: zw, h: zh };
}

export function evenSize(w: number, h: number, maxEdge: number) {
  let width = Math.max(2, w);
  let height = Math.max(2, h);
  const edge = Math.max(width, height);
  if (edge > maxEdge && maxEdge >= 2) {
    const s = maxEdge / edge;
    width *= s;
    height *= s;
  }
  width = Math.max(2, Math.round(width / 2) * 2);
  height = Math.max(2, Math.round(height / 2) * 2);
  return { width, height };
}

export function paintVignette(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const g = ctx.createRadialGradient(
    w / 2,
    h / 2,
    Math.min(w, h) * 0.38,
    w / 2,
    h / 2,
    Math.max(w, h) * 0.68,
  );
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.55)");
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.filter = "none";
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

function drawFrame(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement,
  width: number,
  height: number,
  crop: Crop,
  cssFilter: string,
  mirror: boolean,
) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.filter = "none";
  ctx.clearRect(0, 0, width, height);
  ctx.filter = cssFilter && cssFilter !== "none" ? cssFilter : "none";
  if (mirror) {
    ctx.translate(width, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(video, crop.x, crop.y, crop.w, crop.h, 0, 0, width, height);
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.filter = "none";
}

function smoothstep(t: number) {
  const x = clamp(t, 0, 1);
  return x * x * (3 - 2 * x);
}

export function applyHdr(data: Uint8ClampedArray) {
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i] ?? 0;
    const g = data[i + 1] ?? 0;
    const b = data[i + 2] ?? 0;
    const l = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    const shadow = (1 - smoothstep(l / 0.48)) * 0.2;
    const high = smoothstep((l - 0.62) / 0.38) * 0.26;
    const gain = 1 + shadow - high;
    const avg = (r + g + b) / 3;
    const sat = 1.05;
    data[i] = clamp8((avg + (r - avg) * sat) * gain);
    data[i + 1] = clamp8((avg + (g - avg) * sat) * gain);
    data[i + 2] = clamp8((avg + (b - avg) * sat) * gain);
  }
}

export function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality?: number) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("এনকোড ব্যর্থ"))), type, quality);
  });
}

export async function makeThumb(source: CanvasImageSource, sw: number, sh: number) {
  const t = document.createElement("canvas");
  const width = 480;
  const height = Math.max(2, Math.round((sh / Math.max(1, sw)) * width));
  t.width = width;
  t.height = height;
  t.getContext("2d")?.drawImage(source, 0, 0, sw, sh, 0, 0, width, height);
  return canvasToBlob(t, "image/jpeg", 0.72);
}

export async function captureStill(opts: {
  video: HTMLVideoElement;
  ratio: number | null;
  digital: number;
  cssFilter: string;
  mirror: boolean;
  vignette: boolean;
  hdr: boolean;
  durationMs: number;
  maxEdge: number;
  mime: "image/jpeg" | "image/png";
  quality: number;
  onProgress?: (n: number) => void;
  isCancelled?: () => boolean;
}) {
  const video = opts.video;
  if (!video.videoWidth) throw new Error("ক্যামেরা এখনও প্রস্তুত নয়");
  const crop = frameCrop(video.videoWidth, video.videoHeight, opts.ratio, opts.digital);
  const long = opts.durationMs > 50;
  const edgeCap = long ? Math.min(opts.maxEdge, 1600) : Math.min(opts.maxEdge, 3200);
  const { width, height } = evenSize(crop.w, crop.h, edgeCap);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("ক্যানভাস তৈরি হয়নি");

  const finish = async () => {
    if (opts.vignette) paintVignette(ctx, width, height);
    const blob = await canvasToBlob(
      canvas,
      opts.mime,
      opts.mime === "image/jpeg" ? opts.quality : undefined,
    );
    const thumb = await makeThumb(canvas, width, height);
    return { blob, thumb, width, height };
  };

  if (!long) {
    drawFrame(ctx, video, width, height, crop, opts.cssFilter, opts.mirror);
    if (opts.hdr) {
      const img = ctx.getImageData(0, 0, width, height);
      applyHdr(img.data);
      ctx.putImageData(img, 0, 0);
    }
    return finish();
  }

  const acc = new Float32Array(width * height * 3);
  let count = 0;
  const t0 = performance.now();
  while (count < 90) {
    if (opts.isCancelled?.()) throw new DOMException("বাতিল", "AbortError");
    drawFrame(ctx, video, width, height, crop, opts.cssFilter, opts.mirror);
    const data = ctx.getImageData(0, 0, width, height).data;
    for (let p = 0, i = 0; i < data.length; i += 4, p += 3) {
      acc[p] = (acc[p] ?? 0) + (data[i] ?? 0);
      acc[p + 1] = (acc[p + 1] ?? 0) + (data[i + 1] ?? 0);
      acc[p + 2] = (acc[p + 2] ?? 0) + (data[i + 2] ?? 0);
    }
    count += 1;
    const elapsed = performance.now() - t0;
    opts.onProgress?.(Math.min(0.98, elapsed / opts.durationMs));
    if (elapsed >= opts.durationMs) break;
    await wait(16);
  }
  const out = ctx.createImageData(width, height);
  const od = out.data;
  for (let p = 0, i = 0; i < od.length; i += 4, p += 3) {
    od[i] = clamp8((acc[p] ?? 0) / count);
    od[i + 1] = clamp8((acc[p + 1] ?? 0) / count);
    od[i + 2] = clamp8((acc[p + 2] ?? 0) / count);
    od[i + 3] = 255;
  }
  if (opts.hdr) applyHdr(od);
  ctx.putImageData(out, 0, 0);
  return finish();
}

export function sceneLuma(video: HTMLVideoElement) {
  if (!video.videoWidth) return 128;
  const c = document.createElement("canvas");
  c.width = 32;
  c.height = 18;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  if (!ctx) return 128;
  ctx.drawImage(video, 0, 0, 32, 18);
  const data = ctx.getImageData(0, 0, 32, 18).data;
  let sum = 0;
  let n = 0;
  for (let i = 0; i < data.length; i += 4) {
    sum += 0.2126 * (data[i] ?? 0) + 0.7152 * (data[i + 1] ?? 0) + 0.0722 * (data[i + 2] ?? 0);
    n += 1;
  }
  return n ? sum / n : 128;
}

export function readCaps(track: MediaStreamTrack): CamCaps {
  const raw = (
    typeof track.getCapabilities === "function" ? track.getCapabilities() : {}
  ) as Record<string, unknown>;
  const range = (v: unknown) => {
    if (!v || typeof v !== "object") return undefined;
    const r = v as { min?: unknown; max?: unknown; step?: unknown };
    if (typeof r.min !== "number" || typeof r.max !== "number") return undefined;
    return { min: r.min, max: r.max, step: typeof r.step === "number" ? r.step : undefined };
  };
  const list = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);
  return {
    zoom: range(raw.zoom),
    torch: raw.torch === true,
    exposureCompensation: range(raw.exposureCompensation),
    colorTemperature: range(raw.colorTemperature),
    focusModes: list(raw.focusMode),
    exposureModes: list(raw.exposureMode),
    whiteBalanceModes: list(raw.whiteBalanceMode),
    pointsOfInterest: raw.pointsOfInterest === true,
    imageStabilization: raw.imageStabilization === true || Array.isArray(raw.imageStabilization),
  };
}

async function trySet(track: MediaStreamTrack, constraint: Record<string, unknown>) {
  try {
    await track.applyConstraints({ advanced: [constraint] } as unknown as MediaTrackConstraints);
    return true;
  } catch {
    try {
      await track.applyConstraints(constraint as MediaTrackConstraints);
      return true;
    } catch {
      return false;
    }
  }
}

export async function applyLook(
  track: MediaStreamTrack,
  s: {
    zoom: number;
    ev: number;
    iso: Iso;
    wb: number | "auto";
    flash: FlashMode;
    aeLock: boolean;
    stabilization: boolean;
    filter: FilterId;
  },
  caps: CamCaps,
) {
  let evLeft = s.ev + isoStops(s.iso);
  let wbSoft = s.wb !== "auto";
  let digital = Math.max(1, s.zoom);

  if (caps.zoom) {
    const hw = clamp(s.zoom, caps.zoom.min, caps.zoom.max);
    const ok = await trySet(track, { zoom: hw });
    digital = ok ? Math.max(1, s.zoom / hw) : Math.max(1, s.zoom);
  }

  if (caps.exposureCompensation) {
    const hw = clamp(evLeft, caps.exposureCompensation.min, caps.exposureCompensation.max);
    if (await trySet(track, { exposureCompensation: hw })) evLeft -= hw;
  }

  if (s.aeLock && caps.exposureModes.includes("manual")) await trySet(track, { exposureMode: "manual" });
  else if (!s.aeLock && caps.exposureModes.includes("continuous")) {
    await trySet(track, { exposureMode: "continuous" });
  }

  if (s.aeLock && caps.focusModes.includes("manual")) await trySet(track, { focusMode: "manual" });
  else if (!s.aeLock && caps.focusModes.includes("continuous")) {
    await trySet(track, { focusMode: "continuous" });
  }

  if (s.wb !== "auto" && caps.colorTemperature && caps.whiteBalanceModes.includes("manual")) {
    const k = clamp(s.wb, caps.colorTemperature.min, caps.colorTemperature.max);
    const okMode = await trySet(track, { whiteBalanceMode: "manual" });
    const okK = await trySet(track, { colorTemperature: k });
    if (okMode && okK) wbSoft = false;
  } else if (s.wb === "auto" && caps.whiteBalanceModes.includes("continuous")) {
    await trySet(track, { whiteBalanceMode: "continuous" });
  }

  if (caps.torch) await trySet(track, { torch: s.flash === "on" });
  if (s.stabilization && caps.imageStabilization) await trySet(track, { imageStabilization: true });

  return { css: composeCss(s.filter, evLeft, s.wb, wbSoft), digital };
}

export async function focusAt(
  track: MediaStreamTrack,
  x: number,
  y: number,
  caps: CamCaps,
  mirrored: boolean,
) {
  if (!caps.pointsOfInterest && !caps.focusModes.includes("single-shot")) return;
  const px = mirrored ? 1 - x : x;
  if (caps.pointsOfInterest) {
    await trySet(track, { pointsOfInterest: [{ x: clamp(px, 0, 1), y: clamp(y, 0, 1) }] });
  }
  if (caps.focusModes.includes("single-shot")) await trySet(track, { focusMode: "single-shot" });
}

export async function setTorch(track: MediaStreamTrack, on: boolean) {
  return trySet(track, { torch: on });
}

export function pickVideoMime() {
  const types = [
    "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
  ];
  if (typeof MediaRecorder === "undefined") return "video/webm";
  for (const type of types) {
    if (MediaRecorder.isTypeSupported(type)) return type;
  }
  return "video/webm";
}

export function extFromMime(mime: string) {
  if (mime.includes("mp4")) return "mp4";
  if (mime.includes("png")) return "png";
  if (mime.includes("jpeg") || mime.includes("jpg")) return "jpg";
  return "webm";
}

export function fileStamp(ext: string) {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  const stamp = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  return `LUMEN_${stamp}.${ext}`;
}

export function formatClock(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function trimZoom(z: number) {
  const r = Math.round(z * 10) / 10;
  return Number.isInteger(r) ? String(r) : r.toFixed(1);
}

export function cameraErrorBn(err: unknown) {
  const name = err instanceof DOMException ? err.name : "";
  if (name === "NotAllowedError" || name === "PermissionDeniedError") {
    return "ক্যামেরার অনুমতি বন্ধ। ব্রাউজারের লক আইকন থেকে ক্যামেরা চালু করে আবার শাটার চাপুন।";
  }
  if (name === "NotFoundError" || name === "DevicesNotFoundError") return "কোনো ক্যামেরা পাওয়া যায়নি।";
  if (name === "NotReadableError" || name === "TrackStartError") {
    return "ক্যামেরা অন্য অ্যাপে খোলা। সেটি বন্ধ করে আবার চেষ্টা করুন।";
  }
  if (name === "OverconstrainedError") return "এই রেজোলিউশন সাপোর্ট করে না। 1080p বেছে নিন।";
  if (name === "SecurityError") return "ক্যামেরা চালাতে নিরাপদ (https) সংযোগ লাগে।";
  if (err instanceof Error && err.message) return err.message;
  return "ক্যামেরা চালু করা যায়নি।";
}

export async function requestOrientation() {
  const ctor = DeviceOrientationEvent as unknown as {
    requestPermission?: () => Promise<string>;
  };
  if (typeof ctor.requestPermission === "function") {
    try {
      return (await ctor.requestPermission()) === "granted";
    } catch {
      return false;
    }
  }
  return true;
}

export class PanoBuilder {
  readonly canvas: HTMLCanvasElement;
  readonly height: number;
  used = 0;
  private last: Uint8ClampedArray | null = null;
  private readonly strip: HTMLCanvasElement;

  constructor(height: number) {
    this.height = Math.max(2, height - (height % 2));
    this.canvas = document.createElement("canvas");
    this.canvas.width = 8192;
    this.canvas.height = this.height;
    this.strip = document.createElement("canvas");
    this.strip.width = 12;
    this.strip.height = this.height;
  }

  push(video: HTMLVideoElement, mirror: boolean, filter: string): boolean | "full" {
    if (!video.videoWidth) return false;
    const ctx = this.strip.getContext("2d", { willReadFrequently: true });
    const dest = this.canvas.getContext("2d");
    if (!ctx || !dest) return false;
    const sw = 12;
    const sx = Math.max(0, Math.round(video.videoWidth / 2 - sw / 2));
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.filter = filter && filter !== "none" ? filter : "none";
    if (mirror) {
      ctx.translate(this.strip.width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(video, sx, 0, sw, video.videoHeight, 0, 0, this.strip.width, this.strip.height);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.filter = "none";
    const data = ctx.getImageData(0, 0, this.strip.width, this.strip.height).data;
    if (this.last) {
      let diff = 0;
      let n = 0;
      for (let i = 0; i < data.length; i += 64) {
        diff += Math.abs((data[i] ?? 0) - (this.last[i] ?? 0));
        n += 1;
      }
      if (n && diff / n < 7) return false;
    }
    if (this.used + this.strip.width > this.canvas.width - 8) return "full";
    dest.drawImage(this.strip, this.used, 0);
    this.used += this.strip.width;
    this.last = new Uint8ClampedArray(data);
    return true;
  }

  async exportJpeg(quality: number) {
    if (this.used < 48) throw new Error("আর একটু ঘুরান — যথেষ্ট দৃশ্য জমেনি");
    const out = document.createElement("canvas");
    out.width = this.used - (this.used % 2);
    out.height = this.height;
    out.getContext("2d")?.drawImage(this.canvas, 0, 0, out.width, this.height, 0, 0, out.width, out.height);
    const blob = await canvasToBlob(out, "image/jpeg", quality);
    const thumb = await makeThumb(out, out.width, out.height);
    return { blob, thumb, width: out.width, height: out.height };
  }
}

export async function encodeFrames(frames: Blob[], fps: number) {
  if (frames.length < 2) throw new Error("কমপক্ষে দুই ফ্রেম লাগে");
  const first = await createImageBitmap(frames[0]!);
  const { width, height } = evenSize(first.width, first.height, 1920);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  canvas.setAttribute("aria-hidden", "true");
  canvas.style.cssText =
    "position:fixed;left:-10000px;top:0;width:2px;height:2px;opacity:0;pointer-events:none";
  document.body.appendChild(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    canvas.remove();
    first.close();
    throw new Error("এনকোড ব্যর্থ");
  }
  const mime = pickVideoMime();
  const stream = canvas.captureStream(fps);
  let rec: MediaRecorder;
  try {
    rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 8_000_000 });
  } catch {
    rec = new MediaRecorder(stream);
  }
  const chunks: Blob[] = [];
  const done = new Promise<Blob>((resolve, reject) => {
    rec.ondataavailable = (e) => {
      if (e.data.size) chunks.push(e.data);
    };
    rec.onerror = () => reject(new Error("ভিডিও এনকোড ব্যর্থ"));
    rec.onstop = () => resolve(new Blob(chunks, { type: rec.mimeType || mime }));
  });
  ctx.drawImage(first, 0, 0, width, height);
  rec.start();
  for (let i = 0; i < frames.length; i += 1) {
    const bmp = i === 0 ? first : await createImageBitmap(frames[i]!);
    ctx.drawImage(bmp, 0, 0, width, height);
    if (i !== 0) bmp.close();
    await wait(1000 / fps);
  }
  first.close();
  await wait(220);
  if (rec.state !== "inactive") rec.stop();
  try {
    return await done;
  } finally {
    stream.getTracks().forEach((t) => t.stop());
    canvas.remove();
  }
}

export function formatEv(ev: number) {
  const rounded = Math.round(ev * 10) / 10;
  const text = Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
  return `${rounded > 0 ? "+" : ""}${text}`;
}

export function lapseLabel(ms: number) {
  if (ms < 1000) return `${ms} ms`;
  return `${ms / 1000}s`;
}

export type Look = { css: string; digital: number };

export function softwareLook(s: {
  filter: FilterId;
  ev: number;
  iso: Iso;
  wb: number | "auto";
  zoom: number;
}): Look {
  return {
    css: composeCss(s.filter, s.ev + isoStops(s.iso), s.wb, true),
    digital: Math.max(1, s.zoom),
  };
}

export function mirroredFacing(mirror: boolean, facing: Facing) {
  return mirror && facing === "user";
}
