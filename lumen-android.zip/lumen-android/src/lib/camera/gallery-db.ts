export type Shot = {
  id: string;
  kind: "photo" | "video";
  blob: Blob;
  thumb: Blob;
  created: number;
  width: number;
  height: number;
  mode: string;
  filter: string;
  name: string;
  mime: string;
  durationMs?: number;
};

const DB_NAME = "lumen-roll";
const STORE = "shots";

function openDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("স্টোরেজ খোলেনি"));
  });
}

function request<T>(req: IDBRequest<T>) {
  return new Promise<T>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("স্টোরেজ ত্রুটি"));
  });
}

export async function listShots() {
  const db = await openDb();
  try {
    const rows = await request(db.transaction(STORE, "readonly").objectStore(STORE).getAll());
    return (rows as Shot[]).sort((a, b) => b.created - a.created);
  } finally {
    db.close();
  }
}

export async function putShot(shot: Shot) {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, "readwrite");
    await request(tx.objectStore(STORE).put(shot));
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("সেভ হয়নি"));
    });
  } finally {
    db.close();
  }
}

export async function deleteShot(id: string) {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, "readwrite");
    await request(tx.objectStore(STORE).delete(id));
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("মুছা যায়নি"));
    });
  } finally {
    db.close();
  }
}
