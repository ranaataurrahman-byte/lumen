import { Capacitor, registerPlugin } from "@capacitor/core";

type GallerySaverPlugin = {
  open(opts: { name: string; mime: string; kind: "photo" | "video" }): Promise<{ id: string }>;
  write(opts: { id: string; data: string }): Promise<void>;
  close(opts: { id: string }): Promise<{ uri: string }>;
  abort(opts: { id: string }): Promise<void>;
};

const GallerySaver = registerPlugin<GallerySaverPlugin>("GallerySaver");

export const isNative = () => Capacitor.isNativePlatform();

const CHUNK = 768 * 1024; // multiple of 3, so every chunk's base64 has no padding

function toBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin);
}

/** Saves a photo/video into the phone's gallery (DCIM/LUMEN). Native only. */
export async function saveToGallery(blob: Blob, name: string, mime?: string) {
  const type = mime || blob.type || "application/octet-stream";
  const kind = type.startsWith("video") ? "video" : "photo";
  const { id } = await GallerySaver.open({ name, mime: type, kind });
  try {
    for (let off = 0; off < blob.size; off += CHUNK) {
      const buf = await blob.slice(off, off + CHUNK).arrayBuffer();
      await GallerySaver.write({ id, data: toBase64(buf) });
    }
    await GallerySaver.close({ id });
  } catch (err) {
    await GallerySaver.abort({ id }).catch(() => undefined);
    throw err;
  }
}
