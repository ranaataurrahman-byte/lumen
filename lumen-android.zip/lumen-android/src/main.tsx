import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { CameraApp } from "@/components/camera/CameraApp";
import "./styles.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <CameraApp />
  </StrictMode>,
);
