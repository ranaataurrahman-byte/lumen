# LUMEN — Android APK (ফোন দিয়েই)

## ধাপ
1. github.com-এ নতুন একটি repository খুলুন (ফোনের ব্রাউজারে "Desktop site" চালু করলে সুবিধা)।
2. এই জিপের **ভেতরের সব ফাইল ও ফোল্ডার** repository-তে আপলোড করুন
   (`.github/workflows/android-apk.yml` ফোল্ডারটিও লাগবে)।
3. Repository-র **Actions** ট্যাব → **Build Android APK** → **Run workflow**।
4. ৫–১০ মিনিট পর সম্পন্ন হলে রান খুলে নিচে **Artifacts** থেকে `lumen-debug-apk` নামান।
5. জিপ খুলে `app-debug.apk` ইনস্টল করুন
   (সেটিংসে "Install unknown apps" অনুমতি দিতে হতে পারে)।

## কী হবে
- ছবি/ভিডিও তোলার সাথে সাথে ফোনের **গ্যালারির DCIM/LUMEN** অ্যালবামে সেভ হবে।
- প্রথমবার ক্যামেরা ও মাইকের অনুমতি চাইবে।

## নোট
- এটি debug APK: নিজের ফোনে ইনস্টলের জন্য ঠিক আছে, Play Store-এর জন্য নয়।
- অ্যাপ আইকন এখন Capacitor-এর ডিফল্ট।
